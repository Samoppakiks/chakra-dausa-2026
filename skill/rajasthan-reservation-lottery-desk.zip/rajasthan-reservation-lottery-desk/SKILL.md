---
name: rajasthan-reservation-lottery-desk
description: Answer any question about seat/office reservation and the reservation LOTTERY (आरक्षण लॉटरी) for Rajasthan local-body elections — panchayat (ZP/PS/GP wards, सरपंच, प्रधान, प्रमुख) and urban (nagar nigam/parishad/palika wards) — from the actual text (Rajasthan Panchayati Raj Act 1994 ss.15–16, PR (Election) Rules 1994 rr.5–10, Municipalities Act 2009 s.6, Municipal Election Rules r.5, the 2026 circulars /42 /62 /64 and DLB letters), the Supreme Court/High Court rulings that bind (K. Krishna Murthy 50% ceiling, Manak Chand, Virender Singh) and the state's own 2026 practice — plus a calculator for how many SC/ST/OBC/women seats a body gets. Use when a Collector, SDM, ADM, election clerk, DEO/DLB staff, party agent, or journalist in Rajasthan asks anything like: कितने स्थान आरक्षित होंगे, महिला स्थान odd number में ऊपर या नीचे, 50% से अधिक हो गया तो, 5% threshold, अवरोही क्रम, नियम 8 common ward, नियम 7(12)/(13) rotation, चक्र पूर्ण/exhausted pot, fresh vs continuing cycle, r.7(11) MLA notice, videography, कार्यवाही विवरण में क्या लिखें, what if the state's number looks wrong, which HC ruling says X, or "how do we round down what". Also for auditing an office's seat sheet or drafting the reference letter to the department. Not for conducting the physical draw itself (see public-lottery-conductor) or for building the tree (rules-to-decision-tree).
argument-hint: [<question in Hindi or English> | quota <tier> <N> <SC> <ST> <Total> | audit <sheet>]
allowed-tools: Read, Bash, Grep, Glob, WebFetch, WebSearch
metadata: {"category": "state election", "tags": ["state election", "reservation", "lottery", "panchayat", "municipal", "rajasthan", "government"], "origin": "dausa-avsar/chakra 2026-08", "language": "hi+en", "version": "1.0 (2026-08-16)"}
---

# rajasthan-reservation-lottery-desk — the help desk for the 2026 reservation lotteries

**Done** = the asker gets a verdict they can act on today, the exact clause behind it (quoted, with number), what the state itself did in 2026 on that point, and — where the text is silent — the *named* declaration they must write into the proceedings or the *named* question only the department can answer. Never a guess dressed as law.

## Answer protocol (follow in order, every time)
1. **Classify the question:** tier (ZP/PS/GP ward · सरपंच · प्रधान · प्रमुख · ULB ward), stage (quantum → lists → r.8 → OBC lot → women's lots → remainder → procedure/record), and whether the asker is *computing*, *conducting*, *recording*, or *defending*.
2. **Check `references/faq.md` first** — 29 questions officers actually asked, each answered verdict → text → practice → record. If the question is there, answer from it (adapt, don't paste).
3. **Find the clause** in `references/rules-verbatim.md` (verbatim Act/Rules/circulars/court text with source-quality notes) and the **node** in `references/reservation-code.md` (numbered decision tree, D-list, statuses). Quote the operative words; give the clause number in Hindi form for spoken use (धारा 15(2), नियम 7(8)(क), परिपत्र 62 पैरा 4(i)).
4. **State the status honestly** using the Code's four buckets: SETTLED-TEXT · SETTLED-CIRCULAR/COURT · OFFICER-DECLARES (text silent — give the recommended declaration text, D-n) · STATE-MUST-DECIDE (Q-n in `references/state-questions.md`; give the default the tool applies meanwhile). Where an office practice differs from the text, say both — "text says X; the state did Y on 13.08.2026" — and recommend following the state's uniform practice for the draw with the difference recorded (see faq Q8).
5. **Numbers:** run `scripts/quota.py` (see below) rather than doing arithmetic in your head; paste its step table. Precision rule: percentages by integer cross-multiplication; the only rounding in the law is on the resulting count (s.16 Explanation).
6. **Courts:** only cite what `references/courts.md` verified. If asked about a ruling that isn't there, say no such ruling was found in the 16.08.2026 sweep and offer to search (WebSearch/WebFetch) — never invent a citation.
7. **Edge cases:** `references/edge-cases.md` — 89 clusters with status and D/Q links; search it before saying "the rules are silent".
8. **Language:** answer in the asker's language. Hindi answers = full, flowing spoken sentences (never clipped telegraphese) and Hindi terms where the office has them — स्पष्टीकरण (Explanation), परन्तुक (proviso), गणना (calculator/computation), निकटतम पूर्णांक, अंश छोड़ा, अवरोही क्रम, चक्रानुक्रम, सामान्य-महिला, कार्यवाही विवरण; clause numbers as धारा/नियम/परिपत्र-पैरा. Hinglish questions → English or Hindi as the asker mixes them. English answers may carry the Hindi one-liner for the room.
9. **Tone/limits:** plain, decisive, no moralising; one recommendation, not a menu. Party-facing or public documents: quote a rule where one exists, say nothing where none exists — no internal conversations, VC references, or "Collector direction". Anything district-specific in the Code (Dausa numbers, one district's declared choices) is an *example of practice*, not state law — label it so.

## The calculator
```bash
python3 scripts/quota.py --tier ps --seats 15 --sc 10004 --st 29388 --total 56907          # PRI members from population
python3 scripts/quota.py --tier zp --seats 37 --sc 284214 --st 398172 --total 1305035
python3 scripts/quota.py --tier ps --seats 19 --sc 29677 --st 17311 --total 119185 --obc-seats 2   # OBC given by Commission
python3 scripts/quota.py --tier ulb --seats 55 --sc-seats 11 --st-seats 6 --obc-seats 9      # ULB: state counts → women ⅓ nearest
python3 scripts/quota.py --tier ps --seats 15 --sc 200 --st 480 --total 1000 --women-total up  # show the Explanation reading
python3 scripts/quota.py --selftest                                                             # reproduces Dausa ZP + 13/14 PS + ULB
```
It prints every step with its clause: SC/ST proportion (s.15(2)+Explanation) → OBC (s.15(3)+proviso, base = body's own SC+ST% as the 2026 Commission did; `--obc-base district` for the Act's literal base) → 50% ceiling trim (Krishna Murthy; proportional SC:ST split, declared) → women (total floor per state practice, `--women-total up` for the literal Explanation; category floors; one-each; general-women residual). Given numbers (`--sc-seats/--st-seats/--obc-seats`) are used as-is and flagged if they breach the ceiling. It does NOT pick which wards — that is the list/lottery stage (Code §§2–5; the public tool).

## Reference map (`references/`)
- `faq.md` — the desk's answers (A which law · B quantum · C lists/rotation · D the sitting · E disagreements) + letter lines to the department.
- `rules-verbatim.md` — every clause verbatim: PR Act ss.15–16 (+ Explanation), rr.5–10, municipal r.5, Circular 62/64, Notification 42, DLB letters, RHC Virender Singh/Jai Singh; source hazards (stale one-third mirrors).
- `reservation-code.md` — THE RESERVATION CODE: ~60 numbered nodes (inputs · predicate · formula · clause · output · status), declarations D-1…D-36, tiers §8.
- `edge-cases.md` — 89 edge cases, answered and refuted-checked, with D/Q links. `state-questions.md` — Q-1…Q-16, exact Hindi wording to send up, with defaults.
- `courts.md` — verified quotes: Krishna Murthy 2010, Gawali 2021, Manak Chand 2010, Virender Singh 2020, Jai Singh 2019; the "no ruling on women rounding" finding.
- `state-practice.md` — the state's 2026 arithmetic as observed (Pramukh 20/41, प्रधान 7/14, ZP 7/10/1, PS sheets at floor(N/2), DLB ⅓ nearest) — precedent, not text.
- `glossary.md` — on-screen term → what the office says (Hindi first).
- `SOURCE-VERSION.txt` — which dausa-avsar commit these copies came from.

## Worked patterns the desk sees most
- **"Odd total, women up or down?"** → text up, state down, no court; follow the state, record the Explanation reading, one seat difference (faq Q8).
- **"Total reservation over 50%?"** → real (SC 2010/2021), women not counted; state trims SC:ST proportionally after OBC; if a *given* number breaches → refer, don't conduct (faq Q5–Q7).
- **"Rotation — what is excluded?"** → members 2026 fresh (¶4(i)); offices continue: same-category holders last time out; r.7(12) serial list for SC/ST, r.7(13) lot-exclusion for OBC/women (whole cycle, category-wise, "cycle" undefined); r.9(3) women's offices silent → declare (faq Q16–Q19).
- **"Which ward gets SC/ST?"** → descending % of the ward's own population, 5% gate (PRI), whole list first, r.8 higher % on a common ward, cascade (faq Q13–Q15).
- **"State's number looks wrong."** → in force unless unlawful on its face; show derivation beside it; refer via Circular 62 ¶6 with the letter line (faq Q6, Q27).

## Maintenance
Canonical copy: `dausa-avsar/skills/rajasthan-reservation-lottery-desk/` (references are copies of `chakra/docs/*` at the commit in SOURCE-VERSION.txt — refresh them when the Code changes). Installed copies: `~/.claude/skills/` (MacBook), Studio `~/.claude/skills/` and `~/clawd/skills/`. Catalogued in skills-catalog under category **state election**. Public tool: https://samoppakiks.github.io/chakra-dausa-2026/ . Sibling skills: rules-to-decision-tree (build the tree), audit-a-hand-sheet (diff an office sheet), public-lottery-conductor (run the draw), viewer-centred-mockup (the tool's screens).
