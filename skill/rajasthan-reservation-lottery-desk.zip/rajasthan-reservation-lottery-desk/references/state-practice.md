# What the State of Rajasthan actually did in 2026 — observable arithmetic (use as precedent, cite as practice, never as text)

> **Citation key (full names on first mention — see instruments.md):** "the Act" = राजस्थान पंचायती राज अधिनियम, 1994 (Act 13 of 1994); "the Rules"/r.n = राजस्थान पंचायती राज (निर्वाचन) नियम, 1994; "Municipalities Act" = राजस्थान नगरपालिका अधिनियम, 2009; "municipal r.5" = राजस्थान नगरपालिका (निर्वाचन) नियम, 1994, नियम 5; "Notification /42" = अधिसूचना क्रमांक एफ.15(24)पंरावि/विधि/आरक्षण/2026/42 दिनांक 24.07.2026 (ग्रामीण विकास एवं पंचायती राज विभाग); "Circular 62" = परिपत्र क्रमांक एफ.15(24)पंरावि/विधि/आरक्षण/2026/62 दिनांक 10.08.2026 (same department); "Circular 64" = परिपत्र क्रमांक …/2026/64 दिनांक 13.08.2026; "DLB 23018/23401/23411/23423/23425/23434" = स्वायत्त शासन विभाग, राजस्थान के पत्र क्रमांक एफ.10(न.पा.)(चुनाव)(जन)/डीएलबी/2026/<number>, dated 31.07 / 12.08 / 12.08 / 13.08 / 14.08 / 14.08.2026; "Krishna Murthy" = K. Krishna Murthy (Dr.) v. Union of India, (2010) 7 SCC 202 (SC, 11.05.2010); "Gawali" = Vikas Kishanrao Gawali v. State of Maharashtra, (2021) 6 SCC 73 (SC, 04.03.2021); "Manak Chand" = Manak Chand v. State of Rajasthan, DB CWP 12935/2009 (Raj HC Jaipur DB, 05.03.2010); "Virender Singh" = Virender Singh v. State of Rajasthan (Raj HC, 26.02.2020); "Jai Singh" = Jai Singh v. State of Rajasthan (Raj HC DB, 13.12.2019).

These are numbers from state/district documents that anyone can check. They tell you how the department resolves the points on which the text is silent or ambiguous. Order of authority stays: Act → Rules → notifications → circulars → court → **state practice** → declared officer choice.

## A. Pramukh (जिला प्रमुख) draw, 13.08.2026, state level (r.10) — press note, PRD
41 districts → OBC 5 (2 women: ब्यावर, सीकर) · SC 8 (4 women: दौसा, भरतपुर, टोंक, धौलपुर) · ST 7 (3 women: सलूम्बर, प्रतापगढ़, अलवर) · सामान्य-महिला 11 · unreserved 10.
- SC+ST+OBC = 20 of 41 = 48.8% (≤ 50%).
- Women total = 2+4+3+11 = **20 of 41 = floor(41/2)** — the odd total was rounded DOWN (the s.16 Explanation read literally would give 21).
- Category women = floor: 4 of 8, 3 of 7, 2 of 5.
- OBC 5 = 21% of the 26 districts left after SC/ST (r.10(3) "out of the remaining districts").
- Press line: "सामान्य, ओबीसी, एससी एवं एसटी सभी श्रेणियों में महिलाओं के लिए 50 प्रतिशत आरक्षण का प्रावधान लागू रहेगा" — a target statement; the arithmetic above is what was done.

## B. प्रधान offices, Dausa ZP (14 PS), state-supplied counts (s.16(2), Circular 62 ¶2)
SC 2 · ST 4 · OBC 1 → 7 of 14 = 50.0% exactly. Women 7 = SC-W 1, ST-W 2, OBC-W 0, GEN-W 4 (floor per category, residual to general).

## C. ZP members, Dausa (37 wards) — office sheet reproduced by the engine
Raw s.15(2) proportion: SC 21.8% × 37 = 8.06 → 8; ST 30.5% × 37 = 11.29 → 11 → 19 of 37 = 51.4% (+ OBC 1 = 54%).
Applied: SC 7 · ST 10 · OBC 1 = 18 of 37 = 48.6% — i.e. cap = floor(37/2) = 18, OBC 1 first, the remaining 17 split SC:ST in population ratio (7.08 → 7, 9.92 → 10). Women 18 = 3/5/0/10.

## D. PS members, Dausa (14 PS) — Collector-signed प्रपत्र-2 (SC/ST) + OBC Commission table (OBC), received 16.08.2026
Every PS lands at exactly floor(N/2): दौसा 4/5/1 (10 of 21) · महवा 3/3/1 · सिकराय 3/5/1 · लालसोट 4/4/1 · बांदीकुई 4/3/4 (11 of 23) · लवाण 3/3/1 · बैजूपाड़ा 2/4/1 · बसवा 2/4/1 · नांगल राजावतान 2/6/0 (8 of 17) · रामगढ़ पचवारा 2/5/1 · सिकन्दरा 5/2/2 · मंडावर 2/4/1 · मनोहरपुर खेडला 4/2/1 · शिवसिंहपुरा 2/5/0.
- Where raw SC+ST proportion exceeded half (9 of 14 PS; up to 76% population), SC and ST were BOTH trimmed to fit under the cap — the proportional (Hamilton) split reproduces 13 of 14; सिकन्दरा kept SC at its raw 5 and cut ST (5/2/2). The text is silent on the split; the district's declared method governs.
- OBC per PS = s.15(3) applied on **each PS's own SC+ST%** with the 70% proviso (नांगल राजावतान 74.5% and शिवसिंहपुरा 75.7% → 0; बांदीकुई 31% → 19% × 23 → 4; सिकन्दरा 39.4% → 2; others 1). The Act's words say "district rural" base — the practice is body-wise (open question Q-11; the given number is in force).

## E. ULB wards, 11 Dausa bodies — DLB अधिसूचना 23401 (12.08.2026)
Category counts given by the state; SC+ST+OBC ≤ 50% everywhere, three bodies at exactly 10 of 20 (मण्डावरी, रामगढ़ पचवारा NP, लवाण NP). Women = **one-third per category, rounded to nearest** (दौसा 55: SC 11→4, ST 6→2, OBC 9→3, GEN 29→10; बांदीकुई 40: 11→4, 1→0, 4→1, 24→8). No women's-total computation — category figures are summed. This follows Manak Chand (2010) reading down the 2009 one-half.

**E′. लवाण correction (17.08.2026, district level under DLB letter एफ.10(नपा)(चुनाव)(जन)/डीएलबी/2026/23425 दिनांक 14.08.2026):** the EO's प्रपत्र-ख header box printed SC 1804 / ST 3209 while its own ward table and योग row read SC 3209 / ST 1804; Census 2011 (Lawan village SC 2,573 = 23.3%, ST 1,398 = 12.7%) confirms the table. अधिसूचना 23401's SC 3 / ST 5 for लवाण inherited the transposed header; the district applied SC 5 (2 women) / ST 3 (1 women), same 8 reserved wards, women total unchanged at 7, EO written confirmation + intimation to DLB annexed to the proceedings. Lesson recorded (dausa-avsar LEARNINGS L9): a header total or a state notification is *derived* from the ward rows — never rewrite the rows to make an aggregate come true; flag the aggregate.

## F. Operative instruments for 2026 (numbers)
- Delegation: Notification F.15(24)पंरावि/विधि/आरक्षण/2026/42 (24.07.2026) — Collector for ZP/PS wards and प्रधान; SDM for GP wards and सरपंच.
- Circular F.15(24)पंरावि/विधि/आरक्षण/2026/62 (10.08.2026) — the operative gloss: members on a **fresh** cycle (¶4(i)); सरपंच/प्रधान offices **continue** the running cycle (¶4(ii)/(iii)); r.8 (¶4(iv)); 50% women in every category (¶4(v)); Scheduled Areas (¶5); refer difficulties to ss.15-16, rr.5-9 (¶6); MLA notice and staggering (¶7); full videography (¶8); helpdesk (¶10).
- Circular /64 (13.08.2026) — dates: district-level draws 17.08.2026, SDM-level 18.08.2026.
- DLB (urban): letters 23018 (31.07 delegation), 23411 (12.08 rules ¶1–10, descending order, common ward → higher %), 23423 (13.08 draw date + recognised parties' notice), 23425 (14.08 clerical corrections), 23434 (14.08 nine points: rotation continues only where wards unchanged/≤5 changed; >⅓ changed / count up / new area / dispute → fresh cycle; <0.5% = clerical).

## G. Things the state has NOT written down (as of 16.08.2026) — see state-questions.md Q-1…Q-16
Whether s.16(5)'s women's half is per tier or pooled (Q-1); odd category halves (Q-4); "cycle completed" for r.7(13) (Q-6); the SC:ST split under the 50% cap; the OBC base (district rural vs body's own) (Q-11); general-women exclusion lookback for offices (r.9(3) silent).
