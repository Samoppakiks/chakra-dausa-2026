# शब्दावली / glossary — every on-screen term → what the office says (persona review, 16 Aug 2026)

| current (v0.3) | हिंदी (default) | English (secondary) | note |
|---|---|---|---|
| W_GEN / W_SC / W_ST / W_OBC | सामान्य-महिला सीटें / SC-महिला सीटें / ST-महिला सीटें / OBC-महिला सीटें | General-women seats / SC-women seats / ST-women seats / OBC-women seats | spell out the full category+women name; never show the underscore-variable form in the default view |
| ceil(), floor() | ऊपर पूर्णांकित / नीचे पूर्णांकित (round up / round down) | rounded up / rounded down | always pair with the worked numeral, e.g. '14 का आधा = 7 (ऊपर पूर्णांकित)' |
| Σ (sigma, 'category-women') | सभी वर्गों की महिला सीटों का जोड़ | sum of women's seats across all categories | replace the symbol with the word 'जोड़'/'कुल' plus the actual computed number |
| rhu() | निकटतम पूर्णांक तक (राउंड-हाफ-अप) | round to nearest whole number (round-half-up) | currently undefined anywhere on screen; spell out fully at first use or replace with a numeral demonstration |
| p_SC, p_ST, P_SC, P | SC जनसंख्या %, ST जनसंख्या %, SC जनसंख्या (संख्या), कुल जनसंख्या | SC population %, ST population %, SC population count, total population | use only the full labels in the default view; drop letter-variable notation |
| N_SC, N_ST, N_OBC | स्वीकृत SC/ST/OBC पदों की संख्या | sanctioned SC/ST/OBC post count | this is the quota count already entered by the officer — no separate symbol is needed to relabel it |
| r.7(8)(a), r.7(12)–(13), r.8, §16(3) proviso, §16(6), 243D(4) | नियम 7(8)(अ) / नियम 7(12)-(13) / नियम 8 / धारा 16(3) परन्तुक / धारा 16(6) / अनुच्छेद 243D(4) | Rule 7(8)(a) / Rule 8 / Section 16(3) proviso, etc. | always use Hindi 'नियम'/'धारा', never the English abbreviation 'r.'/'§'; move to a small side-tag, never the primary sentence |
| Circ. ¶4(i) / ¶4(iii) | परिपत्र 62, पैरा 4(i)/(iii) | Circular 62, paragraph 4(i)/(iii) | ADM and Collector want the circular paragraph shown as the PRIMARY citation (what field officers actually work from); Rule/Section number secondary |
| 'in play' | प्रक्रिया में / अभी विचाराधीन | still in the running / active | status badge for units not yet excluded at this step |
| 'excluded' | बाहर (कारण सहित) | excluded (with reason) | never show the bare word alone — always pair with the actual reason sentence |
| 'HELD SC 2005 2015' | यह इकाई 2005 व 2015 में SC हेतु आरक्षित रह चुकी है | previously reserved for SC in 2005 and 2015 | expand to a full sentence, not coded shorthand |
| 'TAKEN ST-2' / 'TAKEN SC-1' | पहले ही ST सूची में ली जा चुकी (रैंक 2) / पहले ही SC सूची में ली जा चुकी (रैंक 1) | already taken into the ST list (rank 2) | expand tag to sentence form |
| 'NOT SC' / 'NOT ST' repeated per row | (हटाओ — पंक्ति धुंधली/collapsed करो) | (remove — collapse the row instead) | never repeat a negative tag row-by-row; collapse into one line 'शेष N इकाइयां योग्य नहीं' |
| 'STATE' column header | स्थिति | Status | rename to match the rest of the Hindi table headers |
| 'round-2 चिट (cycle exhausted)' | यह इकाई पहले सामान्य-महिला में आरक्षित रह चुकी थी; चक्र पूरा होने पर दोबारा पात्र | second round — re-included once the rotation cycle completed | never show 'cycle exhausted' as a bare English tag; personas repeatedly misread it as a system/machine failure |
| 'pot' (e.g. 'SC-म pot') | चिट सूची / लॉटरी सूची | lottery list | strip the bare English word 'pot' wherever it sits inside a Hindi title |
| 'OBC चिट' | OBC चिट = OBC वर्ग की लॉटरी सूची (first-use gloss) | OBC lottery pool | term itself is fine — Clerk and SDM already understand it — just needs a one-time definition on first appearance |
| 'महिला चिट' | महिला चिट = महिला-सीट हेतु लॉटरी सूची (first-use gloss) | women's-seat lottery pool | same treatment — define once on first appearance |
| '*' asterisk (SC-1*, SC-2*, ST-3*) | * = इस चरण में चुनी गई इकाई | * = unit selected at this step | currently has zero explanation anywhere on screen; rated blocker/major by all four personas |
| 'V0.3' | (हटाओ) चक्र — जिला दौसा आरक्षण एवं लॉटरी प्रणाली | (remove) Chakra — Dausa District Reservation & Lottery System | reads as unfinished/test software on a tool that will anchor a legal proceeding |
| 'live demo' | सक्रिय — दौसा 2026 | Active — Dausa 2026 | 'demo' language undermines trust this is the real data for the real election |
| 'Reset draws (demo)' | केवल अभ्यास हेतु — टाइप कर पुष्टि करें | practice-only reset (typed confirmation required) | three of four personas flagged this as a live-draw safety hazard |
| 'Derivation trace' | गणना का विवरण (वैकल्पिक) | calculation detail (optional, expand) | heading is fine once demoted to an optional expandable section, not the primary display |
| 'Validation gates' / G1-G5 | डेटा जांच सूची — डेटा वैलिडेटेड ✅ | data-check list / data validated | full G1-G5 formula detail moves to a hidden 'तकनीकी जांच' section |
| 'Officer's declarations' / D1-D4 | अधिकारी की पुष्टि (नियम-व्याख्या) | officer's rule-interpretation sign-off | each item rewritten as one plain sentence, citation behind (i), un-pre-ticked; legal-accountability blocker as-is |
| 'LIST CLOSES UP' / 'NEXT UNIT' | (हटाओ — ऊपर एक वाक्य में नियम बताओ) | (remove — state the rule in one sentence above the table instead) | table-only presentation forces the reader to reverse-engineer Rule 8 |
| 'on both lists' | दोनों सूचियों में — टकराव, अगले चरण में तय होगा | on both lists — conflict, resolved in the next step | currently signalled only by a pale-yellow row tint; needs a colour-independent text/CONFLICT flag |
| 'no draw —' | आवश्यकता नहीं (0 पद) | not needed (0 seats) | a bare em-dash is not self-explanatory as a placeholder for zero |
| 'one-each: N_SC=N_ST=N_OBC=1? → 2,4,1 → no' | विशेष नियम (हर वर्ग में ठीक 1 पद) यहां लागू नहीं होता | special one-each rule does not apply here | hide when the condition is false; reads as an unexplained trick question otherwise |
| 'short after OBC draw 1' | OBC ड्रॉ में एक सामान्य इकाई पहले ही ली जा चुकी है, इसलिए सामान्य-महिला पूल में 1 इकाई कम है | general-women pool is short by 1 because the OBC draw already used one general unit | three-word summary doesn't explain the cross-category interaction — the step personas found most frightening |
| आधार column raw code 'r.7(4)–(6) अवरोही क्रम ST-2' | घटते क्रम में ST प्रतिशत — स्थान 2 (नियम-संदर्भ फुटनोट में) | descending ST% rank — position 2 (rule code in a footnote) | this is the actual signed legal document; inline codes move to a numbered footnote matching the Hindi 'नियम' style used in the prose below |
| 'Draft order (auto-filled, clause-cited)' | प्रारूप आदेश (स्वतः तैयार) | draft order (auto-generated) | heading is fine in Hindi; drop the English parenthetical |
| Sidebar English items ('Dashboard', 'Exercise & rules', 'Units & history') | डैशबोर्ड / अभ्यास व नियम / इकाइयां व इतिहास | Dashboard / Exercise & rules / Units & history | make the whole left menu one consistent language (Hindi), matching 'संख्या निर्धारण'/'गणना' already used there |
| Button labels ('Print chits', 'Continue →', 'Freeze pots →', 'MLA notices', 'Proceedings format') | पर्ची प्रिंट करें / आगे बढ़ें → / सूची फ़्रीज़ करें → / विधायक सूचना / कार्यवाही प्रारूप | Print chits / Continue → / Freeze lists → / MLA notices / Proceedings format | keep icons/arrows, translate the label text |
