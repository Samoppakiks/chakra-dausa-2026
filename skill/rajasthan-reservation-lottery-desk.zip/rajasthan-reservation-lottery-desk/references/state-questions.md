# STATE-MUST-DECIDE — closed list (exact questions; why; default the tool uses until answered)

Q-1 (qr10, qr12, qr13, ti21). "क्या धारा 16(5) की 'राज्य में सरपंचों, प्रधानों तथा प्रमुखों के कुल पदों में से कम से कम आधे' की शर्त एक राज्यव्यापी संयुक्त औसत है, अथवा सरपंच, प्रधान एवं प्रमुख प्रत्येक में पृथक 50% चाहिए? कृपया संयुक्त राज्यव्यापी महिला-पद गणना प्रकाशित करें।" Why: decides whether 20/41 women Pramukh is a breach and how each PS/ZP women's office count is certified. Default: per-tier half per PS/ZP (round-half-up), report the pooled figure alongside.

Q-2 (qr11, qr13). "जिला प्रमुख ओबीसी कोटा किस आधार पर — 41 (धारा 16(4) शब्दशः 8.61→9) या शेष 26 जिले (नियम 10(3), 5.46→5)?" Why: statewide statutory quantum. Default: not the district's computation; tool records the 26-base inference.

Q-3 (qr05, lm04, lm05). "जब धारा 15(2)+स्पष्टीकरण का पूर्णांकित अजा/अजजा कोटा नियम 7(1)/(4) के 5% मानदंड वाले वार्डों की संख्या से अधिक हो, तो शेष सीटें रिक्त रहें, 5% में छूट हो, या अगली श्रेणी में जाएँ?" Why: two mandatory clauses collide. Default: cap at the list, record the shortfall, no seat below 5%, refer if material.

Q-4 (qr04, ow05, ow06, lm16). "नियम 7(8)(क) में विषम कोटे का आधा — floor, स्पष्टीकरण के अनुसार ऊपर, या लॉटरी? परिपत्र 62 पैरा 4(v) का 'सभी श्रेणियों में 50%' विषम संख्या पर कैसे लागू हो?" Why: one seat per odd category in every PRI statewide. Default: floor(n/2) per category, general-women residual capped at the pool.

Q-5 (qr08, ow01, ow02). "नियम 7(8)(ख) 'एक-एक स्थान' केवल तीनों में ठीक 1 होने पर लागू है, या दो श्रेणियों में 1 होने पर भी? विजेता वार्ड श्रेणी पहचान रखे?" Default: only at exactly 1-1-1; winner keeps its category; r.7(9) subtracts 1.

Q-6 (rc01, rc17, ow07, ow16). "नियम 7(13) में 'चक्र पूर्ण' का अर्थ; क्या 2026 में सदस्यों हेतु सामान्य-महिला की अपवर्जन-स्मृति भी नये सिरे से है; पदों में सामान्य-महिला का चक्र जारी रहे?" Default: members fresh for every category (no unit identity survives redelimitation); offices: exclusion continues by category incl. GEN-महिला; short pot → cycle complete → restart.

Q-7 (ti14, ti16). "अनुसूचित क्षेत्र में आंशिक रूप से पड़ने वाली पंचायत समिति/ग्राम पंचायत पर धारा 3(ङ) कब लागू; तथा स्वतः-अजजा पद राज्यव्यापी अजजा गणना के भीतर या ऊपर?" Default: the unit's own notified boundary; automatic ST offices counted inside.

Q-8 (pn09, pn10). "आरक्षण आदेश की अंतिमता — हस्ताक्षर, प्रकाशन या आपत्ति-अवधि? जिला-स्तरीय लॉटरी की अंतिम तिथि व विस्तार कौन दे?" Default: final on signature and same-day affixation/upload; ¶7 spacing complied with first, slippage recorded.

Q-9 (pn06, pn02). "क्या कलक्टर/उपखण्ड अधिकारी की प्रत्यायोजित शक्ति उप-प्रत्यायोजित हो सकती है; विधायक पद रिक्त होने पर नियम 7(11) का दायित्व?" Default: named officer personally; vacancy recorded and proceed.

Q-10 (pn05, ow10). "नियम 7(11) 'सरकार द्वारा निर्धारित प्रक्रिया' — पर्ची/लॉटरी की मानक प्रक्रिया व वीडियो-अंतराल पर परिणाम?" Default: declared SOP D-23; unfilmed pot re-drawn.

Q-11 (ti22, ow08). "ओबीसी आयोग का जिला-योग इकाई-वार धारा 15(3)/16(3) गणना से भिन्न हो तो कौन मान्य; लॉटरी के बाद आयोग-संशोधन पर पुनः-लॉटरी?" Default: unit-wise formula; Commission figure as check; post-lot revision → Virender Singh redraw with fresh notice.

Q-12 (qr12). "यदि संभागों की संख्या महिला-प्रमुख लक्ष्य से अधिक हो तो नियम 10(4)(क) की प्रति-संभाग गारंटी कैसे समायोजित हो?" Default: none needed at current scale.

Q-13 (ti13). "क्या नियम 8 नियम 9(2) की सरपंच/प्रधान सूचियों पर भी लागू है?" Default: yes, by analogy and ¶4(iv).

Q-14 (di01, di02). "5% परीक्षण हेतु अजा/अजजा जनसंख्या (2011) व कुल जनसंख्या (2026 परिसीमन) — कौन-सा एकल डेटासेट प्राधिकृत है?" Default: the state-supplied dataset used uniformly, declared (D-5).

Q-15 (rc11, rc12, rc26, ti01). "विभाजन/विलय/आंशिक पुनर्सीमांकन में उत्तराधिकारी इकाई कौन ('नवसृजित' बनाम 'पुनर्गठित') व चक्र-स्थिति कैसे मिले?" Default: the r.4 statement's label; LGD-keyed history; per-constituent exclusion in new PS/ZP.

Q-16 (pn11). "13.08.2026 प्रमुख लॉटरी में नियम 7(11) विधायक-सूचना का अनुपालन कैसे हुआ?" Default: state's own record; district unaffected.
