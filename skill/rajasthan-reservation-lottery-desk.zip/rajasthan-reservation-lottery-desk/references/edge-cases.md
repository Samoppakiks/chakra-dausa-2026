# Edge cases — 89 clusters (D-n = declaration in the Code; Q-n = state question)

## Quantum / rounding
| # | case | tier | answer (short) | clause | status | declaration / question |
|---|---|---|---|---|---|---|
| qr01 | percentage precision manufactures/erases a seat | all | Compute every % by raw cross-multiplication; round only the resulting count; SC and ST rounded separately, never combined | s.15(2); §16 Expl.; s.15(3) | OFFICER-DECLARES | D-1 |
| qr02 | 50% strict vs 70% inclusive cliffs | all | Formula off at x = 50 exactly; floor on up to and including 70; per PRI at each level; office floor per PS/ZP own area | s.15(3)+proviso; s.16(3)+proviso | SETTLED-TEXT | — |
| qr03 | 21% cap prints above 21 in small GPs; boundary | GP ward | Cap bounds the input p; rounded local share above 21% lawful; min(21,50−x) continuous at 29; cliff where N×(50−x)/100 crosses k+0.5 | s.15(3); §16 Expl.; r.7(7) | SETTLED-TEXT | — |
| qr04 | small GPs: rounding eats every open seat; 5-ward overshoot | GP ward | Run r.7(8)-(9) as written; floor per category; GW = W − Σ, capped at the physical pool; no floor protects general-male seats; listed ward with zero quota stays General | s.12(2); s.15(6); r.7(8)-(9); §16 Expl. | OFFICER-DECLARES | D-4, D-32; Q-4 |
| qr05 | list vs quota decoupled | GP/PS/ZP ward | Quota below list → allocate quota only; quota above list → cap at list, record, refer if material; never below 5% | r.7(1),(3),(4)-(6); Circ ¶6 | OFFICER-DECLARES | D-10; Q-3 |
| qr06 | 1- or 2-GP PS breaks rotation/floor | सरपंच | 1-unit list re-reserves same unit each cycle (lawful); BC floor = max(formula, 1) → 1 of 2 offices | r.7(12); r.9(2); s.16(3)+proviso; ¶4(ii) | SETTLED-TEXT | — |
| qr07 | PS straddling two districts / two bases | PS ward, सरपंच | Seats: one 'concerned district' declared (default retained district unless notification says); offices: PS-area total population; OBC lot has no population check | s.15(3); s.16(3); r.7(7); r.9 | OFFICER-DECLARES | D-26 |
| qr08 | women divisor 2 vs 3; one-each rule edges | all | BC-women = floor(BC/2); (b) fires only at 1-1-1; two-of-three at 1 → floor gives 0, both lone seats open to the category | r.7(7); r.7(8)(a)-(b); r.7(9); s.15(5) | OFFICER-DECLARES | D-2, D-3; Q-5 |
| qr09 | SC-women guaranteed at ward tier, only probable at office tier | सरपंच | Bare r.9(3) is one draw; department practice (13.08 Pramukh) is category-stratified; declare stratified pots; office SC/ST counts are state-fixed, not local | r.9(2)-(3); r.7(8)(a); s.16(2); Circ ¶2 | OFFICER-DECLARES | D-20 |
| qr10 | s.16(5) pooled vs per-tier; 'Sarpanch or Pradhan' floor | all | s.16(5) genuinely unresolved (text leans pooled); BC office floor = two independent floors (PS and ZP) | s.16(5); s.15(6); s.16(3); r.9(1)-(2) | STATE-MUST-DECIDE | Q-1 |
| qr11 | s.16(4) flat 21% vs s.16(3); 'Zila Parishad' reference | Pramukh | OBC=5 = 21% of residual 26 (r.10(3)) — inferred; s.16(3)'s ZP-area is live for प्रधान offices, not vestigial | s.16(3),(4); r.10(3); §16 Expl. | STATE-MUST-DECIDE (inferred SETTLED-CIRCULAR) | Q-2 |
| qr12 | r.10(4)(a) per-Division floor vs statewide total | Pramukh | Mechanical for 2026; conflict only if Divisions ≥ per-tier target and only if s.16(5) is per-tier | r.10(4)(a)-(b); s.16(5); §16 Expl. | STATE-MUST-DECIDE | Q-1, Q-12 |
| qr13 | 13.08.2026 Pramukh figures vs formulas | all | OBC base 41 vs 26 unexplained; women 20 vs 21 provisional on Q-1; floor(n/2) pattern descriptive; SC/ST inputs unpublished | s.16(4),(5); r.10(3)-(4); Expl. | STATE-MUST-DECIDE | Q-1, Q-2 |
| qr14 | small office pool rounding distortion | all | s.16(2) tier by tier; one rounding rule; flip distance 100/N pp (0.011 / 0.29 / 2.44); no local adjustment | s.16(1)-(2); §16 Expl. | SETTLED-TEXT | — |

## List mechanics
| # | case | tier | answer (short) | clause | status | declaration / question |
|---|---|---|---|---|---|---|
| lm01 | raw vs rounded % at 5.00% and at ties | all | Cross-multiply raw headcounts; only real ties survive; genuine tie → D-9 ladder; same ward at exactly 5% each election is normal | r.7(1),(4); §16 Expl.; r.8; r.7(11) | OFFICER-DECLARES | D-1, D-9 |
| lm02 | 5% is a percentage floor; 0÷0; delimitation split | GP ward | Percentage floor, no headcount; zero-population ward off all lists and pots pending r.4; split wards tested as finally notified (no look-through) | r.7(1); s.12(2); r.4(4); Virender Singh; Jai Singh | SETTLED-COURT + OFFICER-DECLARES | D-7 |
| lm03 | multi-hamlet ward; ward-level vs GP-level % | GP ward | One population-weighted ratio; ward tier and सरपंच tier are two separate tests (r.9(2) ranks GPs by GP population) | s.15(2); s.16(2); r.7(1); r.9(2) | SETTLED-TEXT | — |
| lm04 | round-up manufactures a shortfall; 0.2-point swing | all | Round the seat fraction once; the swing at the cutoff rank is mechanical; quota above list length has no textual referee | s.15(2); §16 Expl.; r.7(1),(3),(12) | SETTLED-TEXT / STATE-MUST-DECIDE | Q-3 |
| lm05 | quota vs list; empty ST list; mid-sitting exhaustion; PS-wide list; seat growth | PS/ZP ward, प्रधान | Cap at list; empty list → quantum unfilled, recorded; exhaustion → restart same sitting; one list per PRI; quota grows with seat count (2026 members have no carried pointer) | r.7(1),(4),(6),(12); r.9(2); r.10(2); s.13(2) | SETTLED-TEXT + OFFICER-DECLARES | D-10, D-12 |
| lm06 | ties at the cutoff rank | all | Ladder: precision → absolute SC pop → total pop → public lot; record even non-determinative ties (fixes next pointer); note lot is by analogy | r.8; r.7(1)-(3),(11),(12)(i); Circ ¶7-8 | OFFICER-DECLARES | D-9 |
| lm07 | r.8 mechanics: common, cascade, order, dead slot | ZP/PS/GP ward, प्रधान | 'Common' = within quota on both lists (declared); higher % wins; only the losing list cascades; order-independent; loser's slot marked unavailable, no renumbering | r.8+Expl.; r.7(3),(4),(13); s.15(2); Virender Singh | OFFICER-DECLARES | D-14, D-15 |
| lm08 | ward-number order locks wrong wards | GP ward | Build the full descending list, then allocate against rank labels | r.7(1)-(3) | SETTLED-TEXT | — |
| lm10 | r.7(4) gate scope; zero-SC closing act; time gap | all | Per PRI; zero recorded, ST same day; recompute both SC% and ST% from the same corrected base before r.8 | r.7(4); s.15(2); r.5; r.8; Virender Singh | SETTLED-TEXT + OFFICER-DECLARES | D-11, D-30 |
| lm12 | list goes stale before the notified draw | all | SC/ST membership is by rank, not bound to the lot date: refresh before the lot; no re-notice for the membership fix; SC/ST-women tag IS by lot under r.7(11) | r.7(1),(7),(10),(11); s.15(2); Virender Singh; Jai Singh | OFFICER-DECLARES | D-29 |
| lm13 | two officers, two lists, one hamlet | PS ward | GP-ward list (SDM) and PS-constituency list (Collector) are independent; same rank label is coincidence | s.15(2); r.7(1)-(2); Notif /42; Circ ¶1 | SETTLED-TEXT | publish a one-line explanatory note |
| lm15 | one wrong figure re-ranks the list; blank vs tested wards | all | Correction reopens the whole list (cascade), finalised before dependent lots; every ward recorded incl. below-5% | r.7(1),(3); s.15(2); Virender Singh; Jai Singh | SETTLED-COURT + OFFICER-DECLARES | D-8, D-31 |
| lm16 | which SC ward gets the women's tag; odd quota; tag swallowed by r.8 | GP/PS/ZP ward | SC allocated first, ST, then r.8 corrects, then women's lot; tag by lot among the fixed set; odd quota → floor (D-2) | r.8; r.7(3),(8)(a),(10); r.6(1); s.15(5); Virender Singh | SETTLED-TEXT + OFFICER-DECLARES | D-2; Q-4 |

## Rotation cycle
| # | case | tier | answer (short) | clause | status | declaration / question |
|---|---|---|---|---|---|---|
| rc01 | 'exhausted' / 'cycle completed' undefined | PS ward | Pool-then-rank: exhausted = every listed unit served once since last restart; OBC/GEN-W: pot empty or short → cycle complete → restart; a zero-seat election moves nothing | r.7(12)-(13); ¶4(ii) | OFFICER-DECLARES | D-12; Q-6 |
| rc02 | pointer is a position on a re-ranked list | PS ward | Pointer read as the set of units already served; rank the residual pool by current %; short → restart same sitting | r.7(12)(i)-(iii); ¶4(ii) | OFFICER-DECLARES | D-12, D-27 |
| rc03 | unequal rest gaps from wrap-around | PS ward | Arithmetic consequence of r.7(12); no minimum-rest rule; lawful | r.7(12) | SETTLED-TEXT | — |
| rc07 | ward drops below 5% and re-qualifies; bye-election; first-time crosser | GP ward | Members 2026 fresh (no history); a unit off the list enters lot pools at once (r.7(13) same-category only); re-entry at current rank; a bye-election is not a general election (no move) | ¶4(i); r.7(1),(12),(13) | SETTLED-CIRCULAR + SETTLED-TEXT | — |
| rc09 | corrected / countermanded / stayed draws in the register | सरपंच | Only the final signed order counts; a re-run poll under the same reservation = one turn; a stayed result counts as ordered unless the order is set aside | Virender Singh; Jai Singh; r.7(13) | OFFICER-DECLARES | D-25 |
| rc10 | continuing office lists never re-checked | सरपंच | Exclusion memory continues; ranking of the residual pool uses current population data | ¶4(ii); s.15(2)/16(2) 'as nearly as may be'; r.7(1) | OFFICER-DECLARES | D-27 |
| rc11 | brand-new district / unit has zero exclusion history | Pramukh | New units enter with no history (¶4(ii)-(iii) logic); no notional credit exists; state matter for districts | ¶4(ii)-(iii); r.10(5) | SETTLED-CIRCULAR | Q-15 |
| rc12 | GP/PS splits — who inherits | सरपंच | The r.4 statement's label governs: नवसृजित → no history; पुनर्गठित/यथावत (same LGD code) → history kept | ¶4(ii); r.4(4) | SETTLED-CIRCULAR + OFFICER-DECLARES | D-13; Q-15 |
| rc13 | unit transferred to another PS | सरपंच | Register travels with the unit (LGD-keyed); the old list closes the gap by re-ranking the pool, no dead slot | r.7(12); ¶4(ii) | OFFICER-DECLARES | D-13 |
| rc16 | rank-based women's Pramukh slot leaves no lot memory | Pramukh | r.10(5) excludes only by-lot offices; state matter | r.10(2),(4),(5) | SETTLED-TEXT | — (state) |
| rc17 | SC-women ward's forward exclusion | PS ward | Members 2026 fresh; going forward the tag carries its parent-category exclusion only; offices: GEN-W rotates too | ¶4(i); r.7(13) | OFFICER-DECLARES | D-19, D-28; Q-6 |
| rc18 | category-women tag has no selection rule or memory | PS ward | Tag by lot within the category set each cycle; no separate memory | r.7(8)(a),(10); r.6(1) | OFFICER-DECLARES | D-28 |
| rc19 | SC and ST lists pace independently | PS ward | Two lists, no linkage; lawful | r.7(12) | SETTLED-TEXT | — |
| rc20 | renamed unit / same name new boundary | GP ward | Key by LGD code, not name | ¶4(ii); r.4 | OFFICER-DECLARES | D-13 |
| rc22 | post-notification 'typo' correction reopens the list | GP ward | Rebuild the list; redraw dependent lots with fresh notice | Jai Singh; Virender Singh; r.7(11) | SETTLED-COURT + OFFICER-DECLARES | D-31 |
| rc26 | partial redraw has no fresh-cycle trigger | PS ward | Default: touched units are पुनर्गठित/नवसृजित per r.4 label; a fresh member cycle needs a state instruction | ¶4(i); r.4 | STATE-MUST-DECIDE | Q-15 |

## OBC and women lots
| # | case | tier | answer (short) | clause | status | declaration / question |
|---|---|---|---|---|---|---|
| ow01 | one-each rescue fragile at edges | PS/GP ward | Fires only at exactly 1-1-1; otherwise floor(1/2)=0, lone seats stay open to the category | r.7(8)(a)-(b) | OFFICER-DECLARES | D-3; Q-5 |
| ow02 | when 1-1-1 fires: identity, r.7(9), register | GP ward | Winner keeps its category (SC-W etc.); r.7(9) subtracts 1; register: parent-category exclusion only | r.7(8)(b),(9); r.6(1) | OFFICER-DECLARES | D-3, D-28 |
| ow03 | women's sub-lot pool unconfined | GP/PS/ZP ward | Fence: category-women drawn only among that category's allocated units; GEN-W only among unreserved | r.7(3),(6),(7),(10); r.6(1) | OFFICER-DECLARES | D-17 |
| ow04 | r.7(9) 'total' = grand total or remainder | GP/PS/ZP ward | Grand total ("of the total number of seats", r.6(2)); GW capped at the physical pool | r.6(2); r.7(9) | SETTLED-TEXT + OFFICER-DECLARES | D-4 |
| ow05 | sub-quota rounding: floor vs round-up; per-category vs pooled | GP/PS/ZP ward | floor(n/2) per category, then sum (r.7(9) 'aggregate ... under sub-rule (8)') | r.7(8)(a),(9); §16 Expl. | OFFICER-DECLARES | D-2; Q-4 |
| ow06 | Circ ¶4(v) '50% in every category' impossible for odd counts | all | Target, not a per-category count; floor per category; total W ≥ half | Circ ¶4(v); r.6; s.15(5)-(6) | OFFICER-DECLARES | D-2; Q-4 |
| ow07 | ¶4(i) names SC/ST/OBC, not women | GP/PS/ZP ward, सरपंच, प्रधान | Members: no unit identity survives redelimitation → fresh for all lot categories; offices: GEN-W exclusion continues (every reservation rotates) | ¶4(i)-(iii); r.7(13) | OFFICER-DECLARES | D-19; Q-6 |
| ow08 | reopening a closed step | all | Arithmetic shortfall found in-sitting: fix before the order (same notice); external data revision: Virender Singh redraw with fresh notice; Commission revision → Q-11 | Virender Singh; Circ ¶2; r.7(11) | SETTLED-COURT + STATE-MUST-DECIDE | D-25; Q-11 |
| ow09 | GEN-W pool assembled live | PS/ZP ward | One notice covers the whole sitting; each pot roster minuted and shown before its draw; ward-count corrections re-run the arithmetic before signing | r.7(11); Circ ¶7-8; Jai Singh | OFFICER-DECLARES | D-21, D-23 |
| ow10 | duplicate slip, wrong slip, camera gap | ZP/PS/GP ward | One roster; pull drawn slips; wrong slip → stop, remove on camera, re-draw that pot; camera gap → re-draw the unfilmed pot with the room's consent minuted, else fresh notice | Circ ¶8; r.7(11) | OFFICER-DECLARES | D-18, D-23; Q-10 |
| ow11 | OBC lot has no population floor | all | Any remaining ward eligible; office-tier SC/ST use unit-own % | r.7(7); r.9(2) | SETTLED-TEXT | — |
| ow12 | ward OBC seats but no OBC सरपंच office | GP/PS ward | Two bases (district rural vs PS-area total); both lawful | s.15(3); s.16(3) | SETTLED-TEXT | — |
| ow13 | 'OBC and/or General (Women)' double-draw | GP/PS ward | One label per unit; a unit drawn OBC leaves the GEN-W pot | r.7(7),(9),(10); Virender Singh | SETTLED-TEXT | D-18 |
| ow14 | r.9(3) freestanding office women's lot | सरपंच, प्रधान | Stratified pots per PS/ZP (state's own practice); declared | r.9(3); s.16(5) | OFFICER-DECLARES | D-20 |
| ow15 | office SC-women rank vs lot; one or two sessions | PS ward, सरपंच | Lot within category; separate pots in one notified sitting, each minuted | r.7(3),(10); r.9(3) | OFFICER-DECLARES | D-20 |
| ow16 | merged BC+women exclusion starves the women's pot | PS ward | Exclusion by category (OBC pot excludes prior-OBC, GEN-W pot excludes prior-GEN-W); short pot → restart | r.7(13) | OFFICER-DECLARES | D-19 |

## Tier interactions
| # | case | tier | answer (short) | clause | status | declaration / question |
|---|---|---|---|---|---|---|
| ti01 | new PS/ZP from several parents — which cycle | सरपंच, प्रधान | Test exclusion per constituent unit against its own last record; new unit's cycle otherwise fresh; restart when no eligible unit remains | ¶4(ii)-(iii) | OFFICER-DECLARES | D-35; Q-15 |
| ti04 | new district imports patchwork प्रधान history | प्रधान | History travels with the PS (unit-keyed), so exclude as ¶4(iii) says | ¶4(iii) | OFFICER-DECLARES | D-13 |
| ti06 | wards fresh, office continues, same GP | all | Lawful; two instructions | ¶4(i) vs ¶4(ii) | SETTLED-CIRCULAR | D-36 |
| ti08 | Pramukh central vs प्रधान per-district rounding | प्रधान | SC/ST office counts are state-supplied (¶2); no local rounding | s.16(2); r.9(1); Circ ¶2 | SETTLED-CIRCULAR | — |
| ti09 | Pramukh and प्रधान draws uncoordinated | all | No de-duplication rule; a same-cycle 'capture' is lawful | r.9; r.10; Notif /42 | SETTLED-TEXT | — |
| ti10 | SDM and Collector clocks collide | सरपंच, all | One district calendar; no overlap for the same MLA | Circ ¶7; r.7(11) | OFFICER-DECLARES | 7.2 |
| ti12 | registers kept by jurisdiction, not by unit | सरपंच | LGD-keyed register travels with the unit; receiving SDM imports it | r.7(12); r.9(2) | OFFICER-DECLARES | D-13 |
| ti13 | r.8 reaches office lists? | all | Applied by analogy + ¶4(iv) | r.8; r.9(2); ¶4(iv) | OFFICER-DECLARES | D-16; Q-13 |
| ti14 | Scheduled-Area straddling threshold | प्रधान, GP ward, सरपंच | Default: the unit's own notified boundary decides | s.3(e); Circ ¶5 | STATE-MUST-DECIDE | Q-7 |
| ti16 | s.3(e) offices inside or on top of statewide ST count | Pramukh | State matter; default: inside | s.3(e); s.16(2); r.10(2) | STATE-MUST-DECIDE | Q-7 |
| ti18 | Division women's slot vs r.9(3) | Pramukh | Unconnected guarantees; no crediting rule | r.10(4); r.9(3) | SETTLED-TEXT | — |
| ti20 | 'held-last-time' column keyed by unit and office | all | Register column per office type per unit | ¶4(ii)-(iii) | OFFICER-DECLARES | D-36 |
| ti21 | ex-officio सरपंच counted in s.16(5) | all | Counting question folds into Q-1; voting bar irrelevant to reservation | s.13(1)(c)+proviso; s.16(5) | STATE-MUST-DECIDE | Q-1 |
| ti22 | one district OBC figure vs unit-by-unit draws | GP ward | Compute per unit by s.15(3)/16(3); Commission figure is a district check; mismatch recorded | Circ ¶2; s.15(3); r.5 | STATE-MUST-DECIDE | Q-11 |

## Procedure and notice
| # | case | tier | answer (short) | clause | status | declaration / question |
|---|---|---|---|---|---|---|
| pn01 | notice only 'by draw of lots' | all | One notice for the whole sitting incl. SC/ST rank steps | r.7(11) | OFFICER-DECLARES | D-21 |
| pn02 | vacant seat, proxy, lateness | all | Vacancy recorded, proceed; proxy is a guest; start at appointed time | r.7(11) | OFFICER-DECLARES | D-22; Q-9 |
| pn03 | AC/PS/district geometry | PS ward, प्रधान, ZP ward | Notify every MLA whose AC touches the units; stagger; district calendar | r.7(11); Circ ¶7 | OFFICER-DECLARES | D-21; 7.2 |
| pn04 | form, channel, lead time | all | Written, dispatch record, acknowledgement, ≥ 3 clear days | r.7(11) | OFFICER-DECLARES | D-21 |
| pn05 | no SOP for chits/videography | all | Declared SOP; whole-sitting videography | r.7(11); Circ ¶8 | OFFICER-DECLARES | D-23; Q-10 |
| pn06 | who may conduct | all | Delegated officer personally; no sub-delegation | Notif /42; s.98 | OFFICER-DECLARES | D-24; Q-9 |
| pn07 | clerical slip vs re-determination | GP ward | Corrigendum citing video for clerical; redraw with notice for substantive | Virender Singh; Jai Singh | OFFICER-DECLARES | D-25 |
| pn08 | announced vs signed vs portal | GP ward, all | Signed order = announced result; mismatch handled per D-25 | — | OFFICER-DECLARES | D-25 |
| pn09 | no publication/objection window | all | Affix and upload same day; final on signature; changes only per court carve-outs | rr.5-10 silence; r.4 contrast | STATE-MUST-DECIDE | Q-8 |
| pn10 | calendar end-date/extension | all | Comply with ¶7 first; record any slippage; ask the state | Circ ¶1, ¶7 | STATE-MUST-DECIDE | Q-8 |
| pn11 | Pramukh ceremony MLA notice | all | State's own compliance; not the district's | r.10; r.7(11) | STATE-MUST-DECIDE | Q-16 |

## Data inputs
| # | case | tier | answer (short) | clause | status | declaration / question |
|---|---|---|---|---|---|---|
| di01 | 2011 SC/ST counts vs 2026 totals | all | One declared dataset; same figures for numerator and denominator | r.7(1); s.15(2) | OFFICER-DECLARES | D-5; Q-14 |
| di02 | two official figures conflict | GP/PS/ZP ward, प्रधान | Latest finally-notified figure controls; resolved before the list; corrections per Jai Singh | r.4(4); s.15(2) | OFFICER-DECLARES | D-5 |
| di03 | new ward with no figure | all | Pro-rata from parent wards, declared; never blank/exclude by default | r.7(1); Circ ¶2 | OFFICER-DECLARES | D-6 |
| di04 | rural vs total population | PS ward | Total population for r.7(1)/s.15(2); 'rural' only in s.15(3) | s.15(2)-(3); s.16(3); r.7(1) | SETTLED-TEXT | — |
| di05 | percentage of what | GP ward | Ward's own concentration | r.7(1); s.15(2); r.8 Expl.; ¶4(iv) | SETTLED-TEXT | — |
