# Rajasthan PRI reservation — VERBATIM source clauses (assembled 2026-08-15)
Sources: SEC Rajasthan Manual of PR Election Law 2014 (controlling for post-2008 text); IndianKanoon 107852649 (Act) & 172545457 (Rules); India Code PDF; jankalyanfile.rajasthan.gov.in (2026 orders). Where mirrors disagree both versions are given.


## ACT 1994 (ss.12-16, Sch. Areas Act 1999)

### Rajasthan Panchayati Raj Act 1994, s.12(1)
12. Composition of a Panchayat.- (1) A Panchayat shall consist of --
(a) a Sarpanch; and
(b) directly elected Panchas from as many wards as are determined under sub-section (2).
_Note:_ Identical in the India Code and PRS texts.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.12(2) — CURRENT text
(2) The State Government shall, in accordance with such rules as may be framed in this behalf, determine the number of the wards, not being less than five for each Panchayat Circle, and thereupon so divide the Panchayat Circle into single member ward that the population of each ward is, so far as practicable, the same throughout the Panchayat Circle.
_Note:_ Per SEC manual footnote: 'Subs. by Notification No.F-2(26)/Vidhi/2/2009 dated 11.9.2009 published in Rajasthan Gazette Extraordinary, Part 4 (Ka) dated 11.9.2009 with immediate effect (Raj. Act. No. 17 of 2009).'
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.12(2) — OLDER text found (pre-2009, undated repository copy)
(2) The State Government shall, in accordance with such rules as may be framed in this behalf, determine the number of wards for each Panchayat Circle, and thereupon so divide the Panchayat Circle into single member wards that the population of each ward is, so far as practicable, the same throughout the Panchayat Circle.
_Note:_ India Code's and PRS's hosted texts print this older, un-amended wording — they do not show the 2009 (or 2008) amendments at all.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&filename=full_act.pdf&type=actfile

### s.13(1) — CURRENT text
13. Composition of a Panchayat Samiti.- (1) A Panchayat Samiti shall consist of--
(a) directly elected members from as many territorial constituencies as are determined under sub-section (2);
(b) all members of the Legislative Assembly of the State representing constituencies which comprise wholly or partly the Panchayat Samiti area; and
(c) chairpersons of all the Panchayats falling within the Panchayat Samiti :
Provided that the members referred to in clauses (b) and (c) shall have a right to vote in all meetings of the Panchayat Samiti except those for election and removal of the Pradhan or Up-pradhan.
_Note:_ Clause (c) inserted, word 'and' deleted/added, and 'clause (b)' → 'clauses (b) and (c)' substituted by the Rajasthan Panchayati Raj (Amendment) Act, 1999 (Act No.15 of 1999), Raj. Gazette E.O. Part IV(A) dated 30.9.1999, w.e.f. 28.5.1999.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.13(2) — CURRENT text
(2) The State Government shall, in accordance with such rules as may be framed in this behalf, determine the number of territorial constituencies not being less than fifteen, for each Panchayat Samiti area and thereupon so divide such area into single member territorial constituencies that the population of each territorial constituency is, so far as practicable, the same throughout the Panchayat Samiti area.
_Note:_ Substituted by Notification No.F-2(26)/Vidhi/2/2009 dated 11.9.2009 (Raj. Act No.17 of 2009), same commencement as s.12(2) above.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.13(2) — OLDER text found (pre-2009)
(2) The State Government shall, in accordance with such rules as may be framed in this behalf, determine the number of territorial constituencies for each Panchayat Samiti area and thereupon so divide such area into single member territorial constituencies that the population of each territorial constituency is, so far as practicable, the same throughout the Panchayat Samiti area:
Provided that a Panchayat Samiti area having population not exceeding one lakh shall consist of fifteen constituencies and in case of a Panchayat Samiti area whose population exceeds one lakh, then for every fifteen thousand or part thereof in excess of one lakh, the said number of fifteen shall be increased by two.
_Note:_ Same population-tiered proviso printed in India Code's and PRS's texts — none reflect the 2009 substitution.
_Source:_ https://www.legitquest.com/act/rajasthan-panchayats-raj-act-1994/A4CD

### s.15(1)
15. Reservation of Seats.- (1) Seats to be filled by direct election in a Panchayati Raj Institution shall be reserved for --
(a) the Scheduled Castes;
(b) the Scheduled Tribes; and
(c) the Backward Classes,
as also for women in accordance with the provisions contained in the succeeding sub-sections.
_Note:_ Substituted by clause (a) of s.3 of the Rajasthan Panchayati Raj (Amendment) Act, 1994 (Act No.23 of 1994), Raj. Gazette E.O. Part IV(A) dated 6-10-1994, w.e.f. 26-7-1994, for the original sub-section (1). Identical wording in all sources checked.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.15(2)
(2) The number of seats reserved for the Scheduled Castes and the Scheduled Tribes, shall bear, as nearly as may be, the same proportion to the total number of seats to be filled by direct election in a Panchayati Raj Institution as the population of such Castes or, as the case may be, such Tribes in that Panchayati Raj Institution area bears to the total population of the area.
_Note:_ Identical across all sources checked.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.15(3) + proviso
(3) Such percentage, not exceeding twenty one, of seats in a Panchayati Raj Institution at each level shall be reserved for Backward Classes as the percentage of the combined rural population of Scheduled Castes and Scheduled Tribes in the concerned district in relation to the total rural population of the district falls short of fifty.
Provided that at least one seat shall be reserved in each Panchayati Raj Institution at each level for Backward Classes where the combined rural population of Scheduled Castes and Scheduled Tribes in the concerned district does not exceed seventy percent of the total rural population of the district.
_Note:_ 'Twenty one' substituted for the original word 'fifteen' by s.3 of the Raj. Panchayati Raj (2nd Amendment) Ordinance, 1999, Raj. Gazette E.O. Part IV(B) dated 25.10.1999 (later Act No.9 of 2000). Identical across all sources checked.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.15(4) — rotation
(4) Seats reserved in accordance with the provisions contained in the preceding sub-sections may be allotted by rotation to different wards or, as the case may be, different constituencies in the concerned Panchayati Raj Institution.
_Note:_ Identical across all sources checked — this is the only rotation clause s.15 contains; it does not prescribe the rotation mechanics themselves (those are left to Rules).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.15(5) — CURRENT text (women's reservation within SC/ST/BC quota)
(5) Not less than one-half of the total number of seats reserved under sub-sections (2) and (3) shall be reserved for women belonging to the Scheduled Castes, the Scheduled Tribes or, as the case may be, the Backward Classes.
_Note:_ KEY FINDING. SEC manual footnote states in terms: 'Subs. by Raj. Panchayati Raj (2nd Amendment) Act, 2008, published in Raj. Gazette, E.O., Part IV-A dated 11.4.2008' — substituting 'one-half' for the original 'one-third'. This sub-section was itself renumbered from the original sub-section (2) to sub-section (5) by the 1994 amendment (Act No.23 of 1994).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.15(5) — OLDER text found ('one-third', undated in the hosting repositories)
Not less than one-third of the total number of seats reserved under Sub-sections (2) and (3) shall be reserved for women belonging to the Scheduled Castes, the Scheduled Tribes or, as the case may be, the Backward Classes.
_Note:_ Printed identically in India Code's full_act.pdf and legitquest.com. Neither source's footnote list includes any 2008 amendment at all — a repository gap, not evidence the amendment doesn't exist (PRS's own disclaimer: 'Principal Acts may or may not include subsequent amendments').
_Source:_ https://prsindia.org/files/bills_acts/acts_states/rajasthan/1994/Act%20No.%2013%20of%201994%20RJ.pdf

### s.15(6) — CURRENT text (overall women's reservation)
(6) Not less than one-half (including the number of seats reserved for women belonging to the Scheduled Castes, the Scheduled Tribes and the Backward Classes) of the total number of seats to be filled by direct election in every Panchayati Raj Institution shall be reserved for women and such seats may be allotted by rotation to different wards or, as the case may be, constituencies in the concerned Panchayati Raj Institution in such manner as may be prescribed.
_Note:_ Same footnote as s.15(5): substituted 'one-half' for 'one-third' by the Rajasthan Panchayati Raj (2nd Amendment) Act, 2008, Raj. Gazette E.O. Part IV-A dated 11.4.2008. Renumbered from original sub-section (3) to (6) in 1994 (Act No.23 of 1994).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.15(6) — OLDER text found ('one-third')
Not less than one-third (including the number of seats reserved for women belonging to the Scheduled Castes, the Scheduled Tribes and the Backward Classes) of the total number of seats to be filled by direct election in every Panchayati Raj Institution shall be reserved for women and such seats may be allotted by rotation to different wards or, as the case may be, constituencies in the concerned Panchayati Raj Institution in such manner as may be prescribed.
_Note:_ Same gap as s.15(5) above; also this exact 'one-third' wording is what Indian Kanoon's own extraction printed for the parallel s.16(5), suggesting its 2008-amendment note on s.15 may itself be only partly reliable — treat SEC manual as the controlling source.
_Source:_ https://prsindia.org/files/bills_acts/acts_states/rajasthan/1994/Act%20No.%2013%20of%201994%20RJ.pdf

### s.16(1)
16. Reservation of the offices of Chairpersons.- (1) The offices of the Sarpanchas, the Pradhans and the Pramukhs shall be reserved for -
(a) the Scheduled Castes;
(b) the Scheduled Tribes; and
(c) the Backward Classes,
as also for women in accordance with the provisions contained in the succeeding sub-sections.
_Note:_ Whole section substituted by s.4 of the Rajasthan Panchayati Raj (Amendment) Act, 1994 (Act No.23 of 1994) for the original s.16, w.e.f. 26-7-1994. Identical across all sources checked.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.16(2)
(2) The number of each of such offices reserved for the Scheduled Castes and the Scheduled Tribes shall bear, as nearly as may be, the same proportion to the total number of each of such offices in the State as the population of such Castes or, as the case may be, such Tribes in the State bears to the total population of the State.
_Note:_ Identical across all sources checked.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.16(3) + proviso
(3) Such percentage, not exceeding twenty one of offices of Sarpanch or Pradhan in a Panchayat Samiti or Zila Parishad, as the case may be, shall be reserved for Backward Classes, as the percentage of the combined population of Scheduled Castes and Scheduled Tribes in the Panchayat Samiti or Zila Parishad area in relation to the population of such Panchayat Samiti or Zila Parishad area, as the case may be, falls short of fifty.
Provided that at least one office of Sarpanch or Pradhan in a Panchayat Samiti or Zila Parishad shall be reserved for Backward Classes where the combined population of Scheduled Castes and Scheduled Tribes in the Panchayat Samiti or Zila Parishad area, as the case may be, does not exceed seventy percent of the total population of the Panchayat Samiti or Zila Parishad area.
_Note:_ 'Twenty one' substituted for 'fifteen' by the same 2nd Amendment Ordinance/Act of 1999-2000 as s.15(3). Identical across all sources checked.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.16(4)
(4) twenty one percent of the total number of offices of Pramukh in the State shall be reserved for the Backward Classes.
_Note:_ 'Twenty one' substituted by s.15 of Act No.9 of 2000, Raj. Gazette Part-IVA Extraordinary dated 3.5.2000. Identical across all sources checked.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.16(5) — CURRENT text (chairperson offices reserved for women)
(5) Not less than one-half of the total number of offices of Sarpanchas, Pradhans and Pramukhs in the State shall be reserved for women.
_Note:_ Same footnote citation as s.15(5)/(6): 'Subs. by Raj. Panchayati Raj (2nd Amendment) Act, 2008, published in Raj. Gazette, E.O., Part IV-A dated 11.4.2008' — one-half for the original one-third. This is the SEC's own manual and directly controls chairperson-office (Sarpanch/Pradhan/Pramukh) reservation for the 2026 elections.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.16(5) — OLDER text found ('one-third')
(5) Not less than one-third of the total number of offices of Sarpanchas, Pradhans and Pramukhs in the State shall be reserved for women.
_Note:_ Printed in India Code's, PRS's and legitquest's texts, and also in Indian Kanoon's own extraction (which inconsistently DID apply 'one-half' to s.15(5)/(6) but not to this clause) — none of these cites any 2008 amendment for s.16 at all.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&filename=full_act.pdf&type=actfile

### s.16(6) — rotation
(6) Offices reserved under this section shall be allotted by rotation to different Panchayats, Panchayat Samities and Zila Parishads in the State in such manner as may be prescribed.
_Note:_ Identical across all sources checked. The actual rotation mechanics are left to Rules (not retrieved in this session — see gaps).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### s.16, Explanation (fraction/rounding rule — covers both s.15 and s.16)
Explanation.- If a fraction forms part of the number of seats computed under section 15 or offices computed under this section, the number of seats or offices, as the case may be, shall be increased to the next higher number in case the fraction consists of half or more of a seat or office and the fraction shall be ignored in case it consists of less than half of a seat or office.
_Note:_ Identical, verbatim, across every source checked (SEC manual, India Code, PRS, legitquest, Indian Kanoon). This single Explanation, placed at the end of s.16, governs rounding for BOTH s.15 seat-computations and s.16 office-computations.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj (Modification of Provisions in their Application to the Scheduled Areas) Act, 1999 (Act No.16 of 1999), s.1
1. Short title, extent and commencement.- (1) This Act may be called the Rajasthan Panchayati (Modification of Provisions in Their Application to the Scheduled Areas) Act, 1999.
(2) It shall extend to the Scheduled Areas of Rajasthan as referred to in clause (1) of Article 244 of the Constitution except those areas which are administered by a municipality.
(3) It shall be deemed to have come into force on and from 26th day of June, 1999.
_Note:_ Received the assent of the Governor on 30 September 1999. Enacted 'to provide for the modification of the provisions of the Rajasthan Panchayati Raj Act, 1994 (Act No.13 of 1994) in their application to the Scheduled Areas of Rajasthan so as to bring them in conformity with the Provisions of the Panchayats (Extension to the Scheduled Areas) Act, 1996 (Central Act No.40 of 1996).' Notified vide Noti. No. F2(27) Vidhi 2/99 dt. 30.9.99, published in Raj. Gazette Part 4(a) dated 30.9.1999.
_Source:_ https://web.archive.org/web/20181217114552/http://www.rajsec.rajasthan.gov.in/secraj/panchayat/PART4.4.htm

### Scheduled Areas Act 1999, s.2 — Definitions
2. Definitions.- In this Act, unless the context otherwise requires,-
(a) a "village" for the purposes of this Act shall mean a village specified as such by the Governor, by notification in the Official Gazette;
(b) "Panchayati Raj Institution" shall have the same meaning as is assigned to it under the Rajasthan Panchayati Raj Act, 1994 (Act No.13 of 1994).
_Note:_ NB: an earlier web-search snippet mislabelled this Definitions clause as 'Section 3' — the archived primary source confirms Definitions is s.2 and the reservation clause is s.3, as listed in the Act's own index of sections.
_Source:_ https://web.archive.org/web/20181217114552/http://www.rajsec.rajasthan.gov.in/secraj/panchayat/PART4.4.htm

### Scheduled Areas Act 1999, s.3 — Exceptions and modifications (chapeau + (a)-(d))
3. Exceptions and modifications.- Notwithstanding anything contained in the Rajasthan Panchayati Raj Act, 1994 (Act No.13 of 1994) or in any other law for the time being in force, the provisions of the said Act or any other law, as the case may be, shall, as respect to the Scheduled Areas of Rajasthan, be applicable subject to the following exceptions and modifications, namely :-
(a) every village shall have a Gram Sabha consisting of persons whose names are included in the electoral rolls for the Panchayat at the village level;
(b) every Gram Sabha shall be competent to safeguard and preserve the traditions and customs of the people, their cultural identify, community resources and the customary mode of dispute resolution;
(c) every Gram Sabha shall -
(i) approve the plans, programmes and projects for social and economic development before such plans, programmes and projects are taken up for implementation by the Panchayat;
(ii) be responsible for identification or selection of persons as beneficiaries under the poverty alleviation and other programmes;
(d) every Panchayat shall be required to obtain from the Gram Sabha a certification of utilisation of funds by that Panchayat for the plans, programmes and projects referred to in clause (c);
_Note:_ 'identify' and 'utilisation' spellings as printed in the source. This clause overrides the Principal Act 'notwithstanding anything contained' in it.
_Source:_ https://web.archive.org/web/20181217114552/http://www.rajsec.rajasthan.gov.in/secraj/panchayat/PART4.4.htm

### Scheduled Areas Act 1999, s.3(e) — THE ST RESERVATION CLAUSE (seats + all Chairperson offices)
(e) the reservation of seats in the Scheduled Areas at every Panchayati Raj Institution shall be in proportion to the population of the community in that Panchayati Raj Institution for whom reservation is sought to be given under section 15 and 16 of the Rajasthan Panchayati Raj Act, 1994 (Act No.13 of 1994);
Provided that the reservation for the Scheduled Tribes shall not be less than one-half of the total number of seats;
Provided further that all seats of Chairpersons of Panchayati Raj Institutions at all levels shall be reserved for the persons belonging to the Scheduled Tribes;
_Note:_ This is the clause the task asked for by name ('Section 3 — ST reservation of chairperson posts'). The SECOND proviso is the operative rule: in Scheduled Areas, ALL Chairperson offices (Sarpanch/Pradhan/Pramukh) — not merely a proportional share — are reserved for Scheduled Tribe candidates, at every PRI level (Panchayat, Panchayat Samiti, Zila Parishad). The FIRST proviso sets a floor (not less than one-half of seats) for ST member-seat reservation, distinct from and additional to the general s.15/s.16 population-proportion formula.
_Source:_ https://web.archive.org/web/20181217114552/http://www.rajsec.rajasthan.gov.in/secraj/panchayat/PART4.4.htm

### Scheduled Areas Act 1999, s.3(f)-(k) — remaining exceptions/modifications
(f) the State Government may nominate persons belonging to such Scheduled Tribes as have no representation in a Panchayat Samiti or in a Zila Parishad;
Provided that such nomination shall not exceed one-tenth of the total members to be elected in that Panchayati Raj Institution;
(g) the Gram Sabha or the Panchayati Raj Institution at such level, as may be prescribed by the State Government, shall be consulted before making the acquisition of land in the Scheduled Areas for development projects and before re-setting or re-habilitating persons affected by such project in the Scheduled Areas, the actual planning and implementation of the projects in the Scheduled Areas shall be co-ordinated at the State level;
(h) planning and management of minor water bodies, as may be specified by the State Government, in the Scheduled Areas shall be entrusted to Panchayati Raj Institution at such level as may be prescribed;
(i) no prospecting licence or mining lease for minor minerals in the Scheduled Areas shall be granted to any person or body of persons without obtaining prior recommendation of the Gram Sabha or the Panchayati Raj Institution at such level and in such manner as may be prescribed;
(j) no concession for the exploitation of minor minerals by auction in the Scheduled Areas shall be granted without obtaining the recommendation of the Gram Sabha or the Panchayati Raj Institution at such level and in such manner as may be prescribed;
(k) the Panchayati Raj Institution at appropriate level, or Gram Sabha as may be prescribed, in a Scheduled Area, shall have -
(i) the power to enforce prohibition or to regulate or restrict the sale and consumption of any intoxicant subject to such rules as may be made by the State Government in this behalf;
(ii) the ownership of minor forest produce subject to such rules as may be prescribed by the State Government as to control and management of minor forest produce;
(iii) the power to prevent alienation of land in the Scheduled Areas an to take appropriate action in accordance with laws in force in the State, to restore any unlawfully alienated land of a Scheduled Tribe;
(iv) the power to manage village market by whatever name called subject to such rules as may be made by the State Government in this behalf;
(v) the power to exercise control over money landing to the members of Scheduled Tribes;
(vi) the power to exercise control over institutions and functionaries in all social sectors to the extent and in the manner to be specified by the State Government from time to time;
(vii) the power to control over local plan and resources or such plans including tribal sub-plan to the extent and in the manner to be specified by the State Government from time to time.
_Note:_ 'intoxciant', 'an to take', 'landing' (for 'lending') reproduced exactly as printed in the source — likely typographical errors in the original/OCR of the official page, flagged rather than silently corrected.
_Source:_ https://web.archive.org/web/20181217114552/http://www.rajsec.rajasthan.gov.in/secraj/panchayat/PART4.4.htm

### Scheduled Areas Act 1999, s.4 — Power to make rules
4. Power to make rules.- (1) The State Government may make rules, by notification in the Official Gazette, to carry out generally the purposes of this Act.
(2) All rules made under this Act shall, be laid, as soon as may be, after they are so made, before the State Legislature, while it is in session, for a period of not less than fourteen days which may be comprised in one session or into successive sessions, and if, before the expiry of the session in which they are so laid or of the session immediately following, the State Legislature makes any modifications in any of such rules, or resolves that any such rules should not be made, such rule shall thereafter have effect only in such modified form or be of no effect, as the case may be, so however, that any such modification or annulment shall be without prejudice to the viladity of any thing previously done thereunder.
_Note:_ 'viladity' (for 'validity') reproduced exactly as printed in the source.
_Source:_ https://web.archive.org/web/20181217114552/http://www.rajsec.rajasthan.gov.in/secraj/panchayat/PART4.4.htm

### Scheduled Areas Act 1999, s.5 — Repeal and Savings
5. Repeal and Savings.- (1) The Rajasthan Panchayati Raj (Modification of Provisions in their Application to the Scheduled Areas) Ordinance, 1999 (Ordinance No.4 of 1999) is hereby repealed.
(2) Notwithstanding such repeal, all actions taken or orders made under the Ordinance referred in Sub-sec.(1) shall be deemed to have been taken or made under this Act or any other law as modified by this Act.
_Note:_ Confirms the 1999 Act's predecessor was a 1999 Ordinance (No.4 of 1999), now superseded by this Act.
_Source:_ https://web.archive.org/web/20181217114552/http://www.rajsec.rajasthan.gov.in/secraj/panchayat/PART4.4.htm


## ELECTION RULES 1994 (rr.2-11)

### Rule 2(1)-(2) - Definitions
2. Definition.- (1) In these rules, unless the subject or context otherwise requires- (i) "Act" means the Rajasthan Panchayati Raj Act, 1994 (Rajasthan Act No. 13 of 1994); (ii) "Commission" means the State Election Commission as defined in the Act; (iii) "Constituency" means a constituency of a Panchayat Samiti or of a Zila Parishad; (iv) "District Election Officer (Panchayats)" means the officer nominated by the Commission as District Election Officer in consultation with the State Government for 1[preparation of Electoral Roll and] conduct of elections to Panchayati Raj Institutions; (v) "Form" means a form appended to these rules; (vi) "Registration Officer" means the Electoral Registration Officer of a ward or a constituency and includes Assistant Electoral Registration Officer to be nominated by the State Election Commission, in Consultation with the State Government; (vii) "Returning Officer" means the officer appointed as such under these rules and includes an Assistant Returning Officer; (viii) "Section" means a section of the Rajasthan Panchayati Raj Act, 1994; (ix) "Voter list" means the list of voters of the village for which a Panchayat is to be established under section 12 of the Act; and (x) "Ward" means a ward of a Panchayat. (2) The words and expression used but not defined in these rules have the same meaning as are respectively assigned to them in the Act. [Footnote 1: Added vide notification No. F.4(12)L&J/94/RDP/4288, dt. 15 Nov. 94.]
_Note:_ Identical in substance across all three sources (IndianKanoon, India Code PDF, SEC Manual); only trivial OCR spelling variants in the India Code PDF ('Panchyat' for 'Panchayat').
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 5 - Reservation of seats for SC/ST/OBC
5. Reservation of seats for Scheduled Castes/Scheduled Tribes and Other Backward Classes.- The number of wards or constituencies to be reserved for persons belonging to the Scheduled Castes/Scheduled Tribes or Other Backward Classes shall be determined by the Officer authorised by the Government in accordance with the provisions of the Act.
_Note:_ Verbatim-identical across all three sources. Note the India Code PDF renders the same sentence as 'the number of wards of constituencies' (typo 'of' for 'or') - almost certainly an OCR error, since IndianKanoon and the SEC Manual both read 'or'. Rule 5 itself contains no method - it only assigns the determination to 'the Officer authorised by the Government' and defers the actual mechanics to Rule 7 and to Section 15 of the Act (not fetched in this task).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 6(1)-(3) as originally enacted, 1994 (per IndianKanoon and India Code PDF)
6. Reservation for women.- (1) One third of the seats reserved for the Scheduled Castes or the Scheduled Tribes or the Backward[s] Classes shall be reserved for the women belonging to such Castes, Tribes or, as the case may be, Classes. (2) One-third, including the number of seats reserved under sub-rule (1) of the total number of seats shall be reserved for women. (3) The Officer authorised by the Government shall determine the seats to be reserved for women.
_Note:_ CONFLICT WITH RULE 6 BELOW. Both IndianKanoon and the India Code PDF show this ORIGINAL 1994 'one third' wording with no amendment marker of any kind - i.e. they present it as if it were still current law.
_Source:_ https://indiankanoon.org/doc/172545457/

### Rule 6(1)-(3) as amended 2008 (per Rajasthan SEC Manual)
6. Reservation for Women.- (1) 2[One half] of the seats reserved for the Scheduled Castes or the Scheduled Tribes or the Backward Classes shall be reserved for the women belonging to such Castes, Tribes or, as the case may be, Classes. (2) 2[One half], including the number of seats reserved under sub-rule (1), of the total number of seats shall be reserved for women. (3) The Officer authorised by the Government shall determine the seats to be reserved for women. [Footnote 2: Substituted vide notification No. F.4(12)PRD/Legal/Rule/Amend/08/2362, dated 25-6-08 for words "One third".]
_Note:_ MAJOR SOURCE DISAGREEMENT - report both. The Rajasthan State Election Commission's own compiled Manual (dated 2014) shows sub-rules (1) and (2) of Rule 6 amended from 'One third' to 'One half' by notification No. F.4(12)PRD/Legal/Rule/Amend/08/2362 dated 25-6-1994(08). This matches the well-documented public fact that Rajasthan moved to 50% women's reservation in Panchayati Raj Institutions in 2008 (ahead of the 2009 Central 73rd-Amendment push to 50%). Neither IndianKanoon nor the India Code PDF - both queried live in 2026 - reflect this amendment anywhere in their text of Rule 6; both display the stale pre-2008 'one third' wording as if current. For a 2026-election ruleset, the amended 'One half' reading in Rules 6(1) and 6(2) should be treated as the legally operative text, sourced to the SEC Manual, with the caveat that the Manual itself is dated 2014 and no source retrieved is dated later - see gaps.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(1)-(2) - SC identification and special serial numbers
7. Procedure for reservation.- (1) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Scheduled Castes under section 15 of the Act, first identify the wards or constituencies which consist of population of the Scheduled Castes and such wards or constituencies shall be serially arranged in the descending order of percentage of population of Scheduled Castes, excluding the wards and constituencies where such percentage is less than five, and shall be assigned serial numbers as SC 1, SC 2 and so on. (2) The serial numbers so assigned shall be known as special serial numbers for Scheduled Castes.
_Note:_ Verbatim-identical in substance across all three sources (IndianKanoon has 'serial numbers' as 'serial numbers' too; minor comma placement differences only). This is the operative 5% threshold clause for SC identification.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(3) - SC seat allocation incl. women sub-quota
(3) The Officer authorised by the Government shall first allocate the number of seats reserved for SCs (including 2[One half] of such seats reserved for women belonging to the Scheduled Castes) serially to the wards bearing special numbers for Scheduled Castes.
_Note:_ IndianKanoon and India Code PDF both read 'including one third of such seats reserved for women belonging to the Scheduled Castes' - the pre-2008 wording, unflagged as amended. SEC Manual footnote 2 (same page) ties this to notification No. F.4(12)PRD/Legal/Rule/Amend/08/2362 dated 25-6-08.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(4)-(5) - ST identification and special serial numbers
(4) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Scheduled Tribes under section 15 of the Act, after the seats having been determined and allocated under the aforesaid section for SCs, proceed to identify the wards and constituencies which consist of population of Scheduled Tribes and such wards and constituencies shall be serially arranged in the descending order of percentage of population of Scheduled Tribes excluding the wards and constituencies where such percentage is less than five, and shall be assigned serial number[s] as ST 1, ST 2 and so on. (5) The serial number[s] so assigned shall be known as special serial numbers for Scheduled Tribes.
_Note:_ Verbatim-identical across all three sources. Same 5% threshold and descending-order-of-percentage mechanism as SC, run as a separate, sequential list AFTER SC seats are allocated (i.e., not simultaneous).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(6) - ST seat allocation incl. women sub-quota
(6) The Officer authorised by the Government shall, after having allocated the seats reserved for the Scheduled Castes under sub-rule (3), allocate the seats reserved for Scheduled Tribes (including 1[One half] of such seats reserved for women belonging to Scheduled Tribes) serially to the wards bearing special serial numbers for Scheduled Tribes.
_Note:_ IndianKanoon / India Code PDF: 'one third' (unflagged, pre-2008 wording). SEC Manual footnote 1 on this page again cites notification No. F.4(12)PRD/Legal/Rules/Amend/08/2362, dated 25-6-08.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(7) - OBC/BC seat allocation by lot, incl. women sub-quota - THE ASYMMETRY
(7) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Backward Classes under section 15 of the Act, after having determined and allocated seats reserved for the persons belonging to the Scheduled Castes and the Scheduled Tribes (including 1[One half] of the seats reserved for women belonging to such Castes and Tribes), proceed further to allocate such number of seats in the Panchayati Raj Institutions as are required to be reserved for persons belonging to Backward Classes, (including one third of such seats reserved for women belonging to Backward Classes) out of remaining seats by lot.
_Note:_ CRITICAL, EASY-TO-MISS DETAIL confirmed by close reading of the SEC Manual's own footnote markers: within the SAME sub-rule (7), the parenthetical for SC/ST women carries footnote marker '1' (amended 2008, 'One third'->'One half'), but the SECOND parenthetical - 'including one third of such seats reserved for women belonging to Backward Classes' - carries NO footnote marker at all. That means, on the SEC Manual's own annotation, the 2008 amendment raised the women's sub-quota WITHIN the SC and ST reservations to one-half, but did NOT touch the women's sub-quota WITHIN the OBC/Backward-Classes reservation, which remains 'one third' verbatim. IndianKanoon and the India Code PDF show 'one third' for BOTH the SC/ST and the BC women parenthetical (i.e., they show the whole sub-rule in its unamended 1994 form), so they do not surface this asymmetry either way - they simply present stale text throughout. This SC/ST-vs-OBC asymmetry in the women's sub-quota fraction (1/2 vs 1/3) is, as far as this research could establish, real and current, but it rests on ONE source's footnoting; it is flagged as needing independent verification against the Rajasthan Gazette notification itself (No. F.4(12)PRD/Legal/Rule/Amend/08/2362 dated 25-6-08), which was not directly located/fetched.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(8) - deriving the women's sub-quota number, and the single-seat rule
(8) (a) The number of seats reserved for women belonging to the Scheduled Castes or the Scheduled Tribes or, as the case may be, the Backward Classes respectively shall be derived by dividing the seats to be reserved for the SCs or STs or as the case may be BCs by 2[two]. (b) If only one seat each is reserved for SC, ST or BC in any Panchayati Raj Institution, one seat out of the three as determined by draw of lots shall be reserved for women.
_Note:_ IndianKanoon/India Code PDF: 'dividing... by three' (unamended). SEC Manual footnote 2 (page 94) again cites the 25-6-08 notification for 'three'->'two'. NOTE the drafting has NOT been fully reconciled: sub-clause (b) still says 'one seat out of the three' even in the amended Manual text - i.e. the 'three' in clause (a)'s divisor was changed to 'two' by the amendment, but the cross-reference 'out of the three' in clause (b) was left unamended/unreconciled in all three sources examined, including the SEC Manual. This is an apparent drafting inconsistency in the rule as currently in force, present identically in all sources - not a source disagreement, but worth flagging as a genuine textual anomaly for anyone applying the rule.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(9) - residual women's seats
(9) The remaining number of seats reserved for women shall be determined by dividing the total number of seats by 2[two] and number so determined shall be reduced by the aggregate of the number of the seats derived for women belonging to the SCs, STs and BCs under sub-rule (8).
_Note:_ IndianKanoon/India Code PDF: 'dividing the total number of seats by three' (unamended). SEC Manual footnote again cites the 25-6-08 notification.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(10) - allocation of women's seats by lot
(10) The seats so reserved for women under rule 6 shall be allocated by lot.
_Note:_ Verbatim-identical across all three sources; unaffected by the 2008 amendment.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(11) - place/date/time of draw of lots + notice to MLAs (NOTE: this is Rule 7(11), NOT a standalone Rule 11)
(11) Where ever seats are to be reserved by draw of lots, the Officer authorised by the Government shall fix place, date and time for the purpose of drawing lots and inform the members of [the] Legislative Assembly of the constituencies or part of the constituency falling in the district. The lots shall be drawn in accordance with the procedures laid down by the Government in the presence of such members of Legislative Assembly who may choose to be present at the appointed time.
_Note:_ IMPORTANT CORRECTION TO THE TASK'S WORKING ASSUMPTION: this place/date/time-of-draw + MLA-notice text is Rule 7, SUB-RULE (11) - it is NOT a standalone 'Rule 11' as the task brief supposed. All three sources (IndianKanoon, India Code PDF, SEC Manual) agree on this numbering and on the verbatim wording (only trivial variance: India Code PDF/IndianKanoon read 'Wherever' as one word vs the SEC Manual's 'Where ever' as two words - a spelling/OCR variant, not a substantive difference). The actual standalone Rule 11 (see below) is a different, unrelated provision in Chapter III.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(12) - rotation/cycle mechanism for SC/ST special serial numbers across successive elections
(12) In every succeeding general election of the Panchayati Raj Institutions, the list of wards or constituencies bearing special serial number for Scheduled Castes or, as the case may be, Scheduled Tribes shall- (i) continue to be operated serially from special serial number following the special serial number where the allocation of seats reserved for the SCs or, as the case may be, the STs has ended in the preceding election. (ii) be operated till it is exhausted, and (iii) be re-operated from the beginning after it is exhausted.
_Note:_ Verbatim-identical across all three sources (India Code PDF has 'begining' typo for 'beginning', matched by the SEC Manual's identical typo, suggesting a shared upstream OCR/typing source or a genuine typo in the original Gazette text carried through both). This is the ONLY place the Rules define rotation mechanics for SC/ST, and it does so purely procedurally (continue-exhaust-restart on the serial-number list), without ever defining numerically what 'exhausted' means, without addressing where newly created wards/constituencies get inserted into an already-running list, and without addressing ties - see gaps/checklist below.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 7(13) - exclusion rule for OBC/Women lots across successive elections
(13) Wards and constituencies reserved for Backward Classes and women by draw of lots in the first general election shall be excluded while drawing lots for such reservation in succeeding elections till the cycle is completed.
_Note:_ Verbatim-identical across all three sources. This is the operative 'rotation exhaustion' provision for BC/OBC and Women seats specifically (distinct mechanism from SC/ST's serial-number continuation in sub-rule (12)): previously-drawn units are excluded from the lot-pool 'till the cycle is completed', but the rule text never defines what constitutes 'the cycle' being 'completed' (e.g., is it once every unit has been drawn exactly once? Is it district-wide or state-wide? What happens to units created after the cycle started?) - all silent, see gaps.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 8 - SC-vs-ST common-ward tie-break by higher percentage, with worked Explanation
8. Reservation for SCs or STs.- Notwithstanding anything to the contrary contained in rule[s] 6 and 7, where a ward or constituency becomes common to be reserved for SCs/STs, then it will be reserved for SCs or STs, as the case may be, whichever has higher percentage of SCs or STs. Explanation :- While arranging wards or constituencies in descending order for the purpose of making reservation for persons belonging to SCs or STs, if a particular ward or constituency appears in both the lists, where the population of SCs is 14% and those of STs is 11%, in that case ward or constituency will be reserved for SCs.
_Note:_ Verbatim-identical across all three sources, Explanation included with its worked illustration (14% SC vs 11% ST -> reserved for SC). This resolves ONE specific type of conflict (a ward/constituency appearing on both the SC list and the ST list) by higher percentage. It does NOT address a straight percentage TIE (SC% == ST% exactly, or two different wards tied at the same SC% as each other) - silent, see checklist item (c).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 9(1)-(3) - Reservation of offices of Sarpanch and Pradhan
9. Reservation of offices of Sarpanchas and Pradhans.- (1) The Officer authorised by the Government shall determine the number of offices of Sarpanchas and Pradhans as required to be reserved in a Panchayat Samiti or in a Zila Parishad area for persons belonging to SCs, STs, or Backward Classes and women in accordance with the provisions of section 16 of the Act. (2) The number of offices of Sarpanchas and Pradhans so reserved for SCs, STs and OBCs shall be allocated by the Officer authorised by the Government to different Panchayats or Panchayat Samitis, as the case may be, by following the procedure as laid down in rule 7. (3) The Officer authorised by the Government shall determine by draw of lots the offices of Sarpanchas and Pradhans to be reserved in the district for women.
_Note:_ Verbatim-identical across all three sources. Sub-rule (2) expressly imports the whole Rule-7 procedure (descending-order-of-percentage, 5% threshold, serial numbers, and - per the SEC Manual - the amended 1/2 and 1/3 women's fractions) for allocating Sarpanch/Pradhan offices to SC/ST/OBC. Sub-rule (3) makes the women's-office allocation a straight district-wide draw of lots, distinct from rule 7/6's arithmetic-derivation method for members' seats.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 10(1)-(5) - Reservation of office of Pramukh
10. Reservation of office[s] of Pramukh[s].- (1) The Government shall determine the number of offices of Pramukhs to be reserved for SCs/STs/OBCs and women. (2) The number of offices of Pramukhs reserved for SCs and STs shall be allocated by the Government to different districts by arranging them in descending order of the percentage of population of SCs or STs separately, excluding such districts where percentage of population of SCs or STs is less than five, and by following the procedure as laid down in rule 7. (3) After having determined the offices of Pramukhs reserved for SCs and STs, the Government shall allocate the offices of Pramukhs reserved for Backward Classes by drawing lots out of the remaining districts. (4) (a) One office of Pramukh out of the total number of offices of Pramukhs reserved for women shall be allocated to each Division as constituted under the Rajasthan Land Revenue Act, 1956 (Act No. 15 of 1956). The office[s] so allotted to a Division shall further be allocated by draw of lots to a District in the Division by the Government. (b) The remaining number of offices reserved for women shall be allocated by the Government by draw of lots to the districts remaining after the allocation under clause (a). (5) The offices of Pramukh[s] reserved in the State for Backward Classes and women by draw of lots in the first general election, shall be excluded while drawing lots for such reservation in the succeeding elections till the cycle is completed.
_Note:_ Verbatim-identical in substance across all three sources; India Code PDF has an OCR umlaut artifact 'Pramükhs'. Sub-rule (2) applies the SAME 5%-threshold, descending-order-of-percentage, Rule-7 procedure used for wards/constituencies, but now at DISTRICT level (Pramukh = Zila Parishad chairperson, one per district) - i.e. the whole state's set of districts is itself serially ranked by SC%/ST% for Pramukh reservation. Sub-rule (4)(a) is unique to Pramukh reservation: it guarantees one women's-reserved Pramukh office per Revenue Division (as constituted under the Rajasthan Land Revenue Act, 1956) before any further women's-office lots are drawn among remaining districts. Sub-rule (5) mirrors 7(13)'s cycle-exclusion mechanism for BC/women Pramukh offices, with the same undefined 'till the cycle is completed' language.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rule 11(1)-(4) - ACTUAL Rule 11, Chapter III: Preparation of electoral rolls (NOT the draw-of-lots provision)
[CHAPTER-III Electoral Rolls] 11. Preparation of electoral rolls.- (1) The Commission shall subject to the provisions of section 18, cause to be prepared a ward or constituency-wise electoral roll in Hindi in Devnagri script for each Panchayati Raj Institution. (2) (a) The names of electors in a roll for a ward in the case of a Panchayat Circle shall be arranged in the order of the serial number of houses as may be comprised in each ward. (b) The electoral roll for constituency of Panchayat Samiti or Zila Parishad, shall consist of the electoral rolls for the wards or part thereof of Panchayat Circles which are comprised within the constituency concerned, which will be arranged Panchayat Circle-wise on the basis of list arranged under clause (a) of this sub-rule. (3) Whenever limits of wards or constituencies of a Panchayat Circle or Panchayat Samiti or Zila Parishad are revised or when a Panchayat circle or Panchayat Samiti or Zila Parishad is constituted or re-constituted, such roll may be prepared afresh and shall contain names of all persons entitled to be registered after enquiry as electors under the Act, as far as possible. (4) For the purpose of preparing any roll or deciding any claim or objection to a roll, the Electoral Registration Officers and any person employed by him, shall have access to any register of births and deaths and to the admission register of any educational institution and it shall be the duty of every person in charge of any such register to give to the said officer or person such information and such extracts from the said register as he may require. [Footnote: Chapter III substituted vide Notification No. F.(15)Vidhi/PR/94/28, dated 3.12.99 for the existing chapter III.]
_Note:_ Confirms the numbering finding above from an independent angle: the real Rule 11 is about electoral-roll preparation, entirely unrelated to reservation/draw-of-lots. Verbatim-identical across all three sources. Sub-rule (3) is the closest thing in the fetched material to addressing 'newly created units' (checklist item (a)) - but it speaks only to electoral-ROLL preparation when a Panchayat/Samiti/Zila Parishad is 'constituted or re-constituted', not to how such a newly constituted unit is slotted into the SC/ST/OBC/women rotation sequence of Rules 6-7. That rotation-insertion question remains unanswered by anything retrieved in this task.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf


## 2026 ORDERS + PRIOR CYCLES + CASE LAW

### Notification No. F.15(24)पंरावि/विधि/आरक्षण/2026/42, dated 24.07.2026 (RD&PR Dept, Panchayati Raj)
राजस्थान पंचायती राज अधिनियम, 1994 (1994 के अधिनियम संख्या-13) की धारा-98 द्वारा प्रदत्त शक्तियों का प्रयोग करते हुए पंचायती राज संस्थाओं के आम चुनाव, 2026 के लिए राज्य सरकार एतद् द्वारा समस्त जिला कलक्टर्स को अपने क्षेत्राधिकार में आने वाली पंचायत समितियों व जिला परिषद के वार्डों (एकल निर्वाचन क्षेत्रों) के आरक्षण तथा प्रधानों के आरक्षण का निर्धारण कर श्रेणीवार आवंटन करने के लिए तथा समस्त उपखण्ड अधिकारियों को अपने क्षेत्राधिकार में आने वाली पंचायतों के वार्डों (एकल निर्वाचन क्षेत्रों) के आरक्षण तथा सरपंचों के आरक्षण का निर्धारण कर श्रेणीवार आवंटन करने के लिए राजस्थान पंचायती राज अधिनियम, 1994 की धारा-15 व 16 तथा पंचायती राज (निर्वाचन) नियम, 1994 के नियम 5, 6, 7, 8 व 9 की शक्तियां संबंधित जिला कलक्टर एवं उपखण्ड अधिकारी को प्रत्यायोजित करती है। आज्ञा से, (डॉ. जोगा राम), शासन सचिव एवं आयुक्त।
_Note:_ Foundational delegation notification — this is the 'F.15(24)' file series the brief asked about. It is the enclosure ('प्रति संलग्न') referred to in Circular No.62 para 1. Copy addressees include Addl Chief Secy to CM, SEC's Chief Electoral Officer & Secretary, Director Local Self-Govt, all District Collectors, all ZP CEOs, all SDMs.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Notification/O_240726_7cd94e5c-29f0-4be1-a8a4-aee3dc9b3f50.pdf

### Circular No. F.15(24)पंरावि/विधि/आरक्षण/2026/62, dated 10.08.2026, para 1 (recital)
विभागीय अधिसूचना क्रमांक एफ.15(24)पंरावि/विधि/आरक्षण/2026/42 दिनांक 24.07.2026 के द्वारा राजस्थान पंचायती राज अधिनियम, 1994 की धारा-15, 16 एवं पंचायती राज (निर्वाचन) नियम, 1994 के नियम-5 से 9 के प्रावधानों के तहत समस्त जिला कलक्टर्स को अपने क्षेत्राधिकार में आने वाली पंचायत समितियों एवं जिला परिषद के वार्डों (एकल निर्वाचन क्षेत्रों) के आरक्षण तथा प्रधानों के आरक्षण का निर्धारण कर श्रेणीवार आवंटन करने के लिए तथा समस्त उपखण्ड अधिकारियों को अपने क्षेत्राधिकार में आने वाली पंचायतों के वार्डों (एकल निर्वाचन क्षेत्रों) के आरक्षण तथा सरपंचों के आरक्षण का निर्धारण कर श्रेणीवार आवंटन करने के लिए पंचायती राज अधिनियम, 1994 की धारा-98 के तहत अधिकृत किया जा चुका है, प्रति संलग्न है। यह कार्य निर्धारित अवधि में पूर्ण किया जाना है।
_Note:_ Who conducts: Collector = PS-ward/ZP-ward/Pradhan reservation; SDM = Panchayat-ward/Sarpanch reservation.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 2
विभाग द्वारा आपको पूर्व में प्रदत्त निर्देशों की पालना में आप द्वारा ग्राम पंचायतों/पंचायत समितियों/जिला परिषदों के वार्डों तथा सरपंच एवं प्रधान पदों के लिए आरक्षण निर्धारण करने हेतु अनुसूचित जाति एवं अनुसूचित जनजाति के वार्डों एवं स्थानों की कुल संख्या का निर्धारण किया जा चुका है। वहीं अन्य पिछड़ा वर्ग के लिए वार्डों एवं पदों की कुल संख्या का निर्धारण माननीय उच्चतम न्यायालय के विविध प्रार्थना पत्र डायरी संख्या 31495/2021 मनमोहन नागर बनाम मध्यप्रदेश राज्य एवं अन्य में दिनांक 17.12.2021 में पारित निर्णय की अनुपालना में सामाजिक न्याय एवं अधिकारिता विभाग, जयपुर के आदेश क्रमांक एफ.11()रारा.पि.वर्ग(राजनैतिक)/बीसी/सान्याअवि/2025/33822 राजकाज संदर्भ संख्या 13616326 दिनांक 09.05.2025 द्वारा गठित राजस्थान राज्य अन्य पिछड़ा वर्ग (राजनैतिक प्रतिनिधित्व) आयोग के प्रतिवेदन में किया जा चुका है। इस प्रतिवेदन की जिले से संबंधित रिपोर्ट का अंश पत्र के साथ संलग्न है। इस प्रकार से आपके पास राजस्थान पंचायती राज के अधिनियम की धारा 15(2) के अनुसार प्रत्येक संस्था में अनुसूचित जाति, अनुसूचित जनजाति, अन्य पिछड़ा वर्ग हेतु आरक्षित किये जाने वाले वार्डों की संख्या एवं पदों की संख्या उपलब्ध है।
_Note:_ Legal chain for the OBC quantum: Triveni Ballabh/Manmohan Nagar SC order (17.12.2021) -> SJE Dept order dated 09.05.2025 constituting the Rajasthan State OBC (Political Representation) Commission -> that Commission's district reports, an extract of which is annexed district-wise.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 3
भारतीय संविधान के अनु0 243–घ. स्थानों का आरक्षण के उपबन्ध(4) तथा राजस्थान पंचायती राज अधिनियम, 1994 की धारा–16(6) में यह स्पष्ट वर्णित है कि आरक्षित पद चक्रानुक्रम (Rotation) से आवंटित किये जायेंगे।
_Note:_ Constitutional/statutory basis for rotation.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 4(i) — members (ward panch / PS member / ZP member): fresh cycle
पंचायती राज संस्थाओं के तीनों स्तरों के सदस्यों हेतु : हाल ही में राज्य की समस्त ग्राम पंचायतों/पंचायत समितियों एवं जिला परिषदों में वार्डों का पुनर्गठन/पुनर्सीमांकन का कार्य किया गया हैं अतः इन तीनों संस्थाओं के वार्ड पंच/पंचायत समिति सदस्य/जिला परिषद सदस्य हेतु अनुसूचित जाति, अनुसूचित जनजाति तथा अन्य पिछडा वर्ग के लिए श्रेणीवार आवंटन नये चक्रानुक्रम(साईकिल) से किया जावेगा।
_Note:_ Because delimitation/reorganisation of wards has just occurred, member-level (ward) SC/ST/OBC allotment restarts as a NEW rotation cycle in 2026 — this is the answer to 'cycle continuation vs fresh' for members.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 4(ii) — Sarpanch office: cycle continues + new-PS treatment
सरपंच पद हेतु : सरपंच पदों हेतु श्रेणीवार आवंटन के लिए पुनर्गठित एवं यथावत रही पंचायत समितियों में सरपंच पद का श्रेणीवार आवंटन वर्तमान चक्रानुक्रम (साईकिल) जिसके आधार पर गत चुनाव सम्पन्न करवाये गये थे, के अनुसार ही किया जावेगा। अतः नवसृजित पंचायत समितियों में भी सरपंच पद का श्रेणीवार आवंटन करते समय यह ध्यान रखा जाये कि उस पंचायत समिति में जो ग्राम पंचायत नवसृजित नहीं है अर्थात् यथावत अथवा पुनर्गठित है और वह ग्राम पंचायत पिछले चुनाव में अनुसूचित जाति, अनुसूचित जनजाति तथा अन्य पिछडा वर्ग के लिए आरक्षित रही थी, उसे उसी श्रेणी के लिए आरक्षण हेतु सम्मिलित नहीं किया जाये। यदि चक्र पूर्ण हो गया तो नये सिरे से नवीन पंचायत समिति के लिये चक्र प्रारम्भ किया जा सकेगा।
_Note:_ For the Sarpanch OFFICE (as opposed to ward-member seats), the existing rotation cycle continues unbroken; treatment of newly-created Panchayat Samitis: a gram panchayat that is not itself newly-created (i.e. carried over as-is or merely reconstituted) and was SC/ST/OBC-reserved last time is EXCLUDED from repeat-reservation in the same category this round, unless the whole cycle has already been exhausted, in which case the cycle restarts fresh for that new unit.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 4(iii) — Pradhan office: cycle continues + new-ZP treatment
प्रधान पद हेतु : प्रधान पदों हेतु श्रेणीवार आवंटन के लिए पुनर्गठित एवं यथावत रही जिला परिषदों में प्रधान पद का श्रेणीवार आवंटन वर्तमान चक्रानुक्रम (साईकिल) जिसके आधार पर गत चुनाव सम्पन्न करवाये गये थे, के अनुसार ही किया जावेगा। अतः नवसृजित जिला परिषदों में भी प्रधान पद का श्रेणीवार आवंटन करते समय यह ध्यान रखा जाये कि उस जिला परिषद में जो पंचायत समिति नवसृजित नहीं है अर्थात् यथावत अथवा पुनर्गठित है और वह पंचायत समिति पिछले चुनाव में अनुसूचित जाति, अनुसूचित जनजाति तथा अन्य पिछडा वर्ग के लिए आरक्षित रही थी, उसे उसी श्रेणी के लिए आरक्षण हेतु सम्मिलित नहीं किया जाये। यदि चक्र पूर्ण हो गया तो नये सिरे से नवीन जिला परिषद के लिये चक्र प्रारम्भ किया जा सकेगा।
_Note:_ Same logic as 4(ii) one level up: Pradhan office cycle continues; newly-created Panchayat Samitis get the same carve-out (exclude non-new units already SC/ST/OBC-reserved last cycle, unless cycle exhausted).
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 4(iv) — SC/ST tie
यदि कोई स्थान (सीट) अनुसूचित जाति, अनुसूचित जनजाति दोनों श्रेणी के लिए आरक्षण में आ रहा है तो जिस श्रेणी का जनसंख्या प्रतिशत अधिक होगा, वह स्थान उसी श्रेणी के लिए आरक्षित किया जायेगा।
_Note:_ Matches Rule 8 of the 1994 Election Rules verbatim in substance (see below).
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 4(v) — women's fraction
महिलाओं हेतु : महिलाओं का आरक्षण राजस्थान पंचायती राज अधिनियम, 1994 की धारा–15(5) एवं राजस्थान पंचायती राज (निर्वाचन) नियम, 1994 के नियम–06 के अनुसार सभी वर्गों/श्रेणियों में 50 प्रतिशत रखा जावेगा।
_Note:_ NOTE: the Act text itself (Ss.15(5)/(6), 16(5)) says 'not less than one-third'; the Rajasthan government, in this 2026 circular, is applying 50% across every category as a matter of policy/higher state commitment — flagging this as a point where the operative instruction goes beyond the bare statutory floor.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 5 — Scheduled Areas special provision
अनुसूचित क्षेत्रों (Scheduled Area) के लिए विशेष व्यवस्था:– भारत सरकार द्वारा राज्य के अनुसूचित क्षेत्रों (भारत सरकार द्वारा अधिसूचित अनुसूचित क्षेत्र (राजस्थान राज्य) आदेश, 2018 दिनांक 19 मई, 2018 में वर्णित क्षेत्रों का पुनः निर्धारण किया गया है(प्रति संलग्न है)। राजस्थान पंचायती राज (उपबन्धों अनुसूचित क्षेत्रों में उनके लागू होने के संबंध में उपरान्त) अधिनियम, 1999 की धारा–3 के अनुरूप अनुसूचित क्षेत्रों में अध्यक्ष के समस्त पद (ग्राम पंचायत, पंचायत समिति, जिला परिषद) अनुसूचित जनजाति के लिए आरक्षित है। परन्तु इन स्थानों में से 1/2 स्थान अनुसूचित जनजाति महिलाओं के लिए आरक्षित रहेगे। जिन जिलों में जो पंचायत समितियां एवं ग्राम पंचायतें अनुसूचित क्षेत्रों के अंतर्गत नहीं आती है, उनमें आरक्षण राजस्थान पंचायती राज अधिनियम, 1994 की धारा–15 व 16 तथा पंचायती राज (निर्वाचन) नियम,1994 के नियम–5 से 9 के प्रावधानों के अनुसार किया जावेगा।
_Note:_ In the four Fifth-Schedule TSP districts (Banswara, Dungarpur, Pratapgarh, and the specified tehsils of Udaipur/Rajsamand/Chittorgarh/Pali/Sirohi per the 2018 Presidential Order), EVERY chairperson office (Sarpanch/Pradhan/ZP-Pramukh-level within scheduled blocks) is ST-reserved, with half of those specifically for ST women — overriding the general rotation in those pockets.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 6 — escalation for legal difficulty
आरक्षित पदों के निर्धारण हेतु किसी भी प्रकार की प्रक्रियात्मक या विधिक कठिनाई आने पर कृपया, राजस्थान पंचायती राज अधिनियम, 1994 की धारा–15 व 16 और पंचायती राज (निर्वाचन) नियम, 1994 के नियम–5 से 9 का संदर्भ लेवें।
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 7 — notice to MLAs for lottery
उक्त कार्यवाही में जहां आरक्षण के लिए लॉटरी निकाली जावेगी, वहां नियम 7(11) की पालना में लॉटरी के लिए निर्धारित समय, स्थान व तिथि की सूचना संबंधित विधानसभा सदस्य को दी जानी है। यदि किसी विधानसभा क्षेत्र में एक से अधिक पंचायत समितियां है तो समय, स्थान व तिथियों का निर्धारण इस प्रकार किया जावे कि विधानसभा सदस्य को प्रत्येक लॉटरी के समय उपस्थित रहने का अवसर मिल सके।
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 8 — videography (BINDING)
लॉटरी की सम्पूर्ण प्रक्रिया की विडियोग्राफी कराया जाना सुनिश्चित करें।
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 9 — seating for observers
लॉटरी के प्रक्रिया के दौरान उपस्थित सभी व्यक्तयों के लिये उचित बैठक व्यवस्था रखी जावें।
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Circular No. 62, para 10 — helpdesk for legal difficulty
आरक्षित पदों के निर्धारण हेतु किसी भी प्रकार की प्रक्रियात्मक या विधिक कठिनाई आने पर श्री बी0डी0 कृपलानी, सलाहकार से मोबाईल नम्बर 9414251727 पर सम्पर्क किया जा सकता है। संलग्नः–उपरोक्तानुसार। (डॉ0 जोगा राम), शासन सचिव एवं आयुक्त, दिनांक 10.08.2026
_Note:_ Distribution/copy list (प्रतिलिपि) includes Addl Chief Secy to CM; Private Secys to the PRD Minister, RD Minister and PRD State Minister; Secy PRD; Secy RD; Chief Electoral Officer & Secretary SEC; all Zila Parishad CEOs; ACP HQ for website upload; guard file.
_Source:_ https://jankalyanfile.rajasthan.gov.in/Files//Content/UploadFolder/OrderEntry/P_R/2026/Circular/O_120826_c38d7c0c-8769-4d4a-95c3-a0d23687617b.pdf

### Panchayati Raj (Election) Rules, 1994 — Rule 5 (SC/ST/OBC reservation, who determines)
Reservation of seats for Scheduled Castes/Scheduled Tribes and Other Backward classes. - The number of wards of constituencies to be reserved for persons belonging to the Scheduled Castes/Scheduled Tribes or Other Backward Classes shall be determined by the Officer authorised by the Government in accordance with the provisions of the Act.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 6 — Reservation for women
(1) One third of the seats reserved for the Scheduled Castes or the Scheduled Tribes or the Backwards Classes shall be reserved for the women belonging to such Castes, Tribes or, as the case may be, Classes. (2) One-third, including the number of seats reserved under sub-rule (1) of the total number of seats shall be reserved for women. (3) The Officer authorised by the Government shall determine the seats to be reserved for women.
_Note:_ Rule text still says one-third; the 2026 operative circular (para 4(v) above) applies 50% instead — flagged as a live discrepancy between codified Rule and the current administrative instruction.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 7(1)-(6) — descending-order procedure for SC then ST
(1) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Scheduled Castes under Sec. 15 of the Act, first identify the wards or constituencies which consist of population of the Scheduled Castes and such wards or constituencies shall be serially arranged in the descending order of percentage of population of Scheduled Caste excluding the wards and constituencies where such percentage is less than five, and shall be assigned serial numbers as SC 1, SC 2 and so on. (2) The serial number so assigned shall be known as special serial number for Scheduled Castes (3) The Officer authorised by the Government shall first allocate the number of seats reserved for SCs (including one-third of such seats reserved for women belonging to the Scheduled Castes) serially to the wards bearing special numbers for Scheduled Castes. (4) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Scheduled Tribes under Sec. 15 of the Act, after the seats having been determined and allocated under the aforesaid section for SCs, proceed to identify the wards and constituencies which consist of population of Scheduled Tribes and such wards and constituencies shall be serially arranged in the descending order of percentage of population of Scheduled Tribes excluding the wards and constituencies where such percentage is less than five, and shall be assigned serial number of ST 1, ST 2 and so on. (5) The serial number so assigned shall be known as special serial numbers for Scheduled Tribes. (6) The Officer authorised by the Government shall, after having allocated the seats reserved for the Scheduled Castes under Sub-rule (3), allocate the seats reserved for Scheduled Tribes (including one-third of such seats reserved for women belonging to Scheduled Tribes) serially to the wards bearing special serial numbers for Scheduled Tribes.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 7(7) — OBC by lot
The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Backward Classes under Sec 15 of the act, after having determined and allocated seats reserved for the persons belonging to the Scheduled Castes and the Scheduled Tribes (including one-third of the seats reserved for women belonging to such Castes and Tribes), proceed further to allocate such number of seats in the Panchayati Raj Institutions as are required to be reserved for persons belonging to Backward Classes (including one-third of such seats reserved for women belonging to Backward Classes) out of remaining seats by lot.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 7(8)-(9) — women's-fraction derivation and ties within the divide-by-three
(8) (a) The number of seats reserved for women belonging to the Scheduled Castes or the Scheduled Tribes or, as the case may be, the Backward Classes respectively shall be derived by dividing the seats to be reserved for the SCs or STs or as the case may be BCs by three. (b) If only one seat each is reserved for SC, ST or BC in any Panchayati Raj Institution, one seat out of the three as determined by draw of lots shall be reserved for women. (9) The remaining number of seats reserved for women shall be determined by dividing the total number of seats by three and number so determined shall be reduced by the aggregate of the number of the seats derived for women belonging to the SCS, ST's and BCs under sub-rule (8)
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 7(10)-(13) — lottery method, MLA notice, cycle continuation, exhaustion
(10) The seats so reserved for women under Rule 6 shall be allocated by lot. (11) Wherever seats are to be reserved by draw of lots, the Officer authorised by the Government shall fix place, date and time for the purpose of drawing lots and inform the members of the Legislative Assembly of the constituencies or part of the constituency falling in the district. The lots shall be drawn in accordance with the procedures laid down by the Government in the presence of such members of Legislative Assembly who may choose to be present at the appointed time. (12) In every succeeding general election of the Panchayati Raj Institutions, the list of wards or constituencies bearing special serial number for Scheduled Castes or, as the case may be, Scheduled Tribes shall- (i) continue to be operated serially from special serial number following the special serial number where the allocation of seats reserved for the SCs or, as the case may be, the STs has ended in the preceding election. (ii) be operated till it is exhausted, and (iii) be re-operated from the beginning after it is exhausted. (13) Wards and constituencies reserved for Backward Classes and Women by draw of lots in the first general election shall be excluded while drawing lots for such reservation in succeeding election till the cycle is completed.
_Note:_ This is the statutory basis for 'cycle continuation vs fresh': SC/ST descending-order lists run serially election-to-election until exhausted, then restart; OBC/women lots exclude previously-reserved units until the cycle completes. Rule 7(11) is the exact MLA-notice provision the 2026 circular's para 7 invokes by name.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 8 — SC/ST tie-break, verbatim
Reservation for SCs or STs. - Notwithstanding anything to the contrary contained in Rules 6 and 7 where a ward or constituency becomes common to be reserved for SCs/STs, then it will be reserved for SCs or STs, as the case may be, whichever has higher percentage of SCs or STs. Explanation-While arranging wards or constituencies in descending order for the purpose of making reservation for persons belonging to SCs or STs, if a particular ward or constituency appears in both the lists, where the population of SCs is 14% and those of STs is 11%, in that case ward or constituency will be reserved for SCs.
_Note:_ Includes the rule's own worked illustration (14% SC vs 11% ST -> SC wins) — matches 2026 circular para 4(iv) exactly.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 9 — Reservation of offices of Sarpanchas and Pradhans
(1) The Officer authorised by the Government shall determine the number of office of Sarpanchas and Pradhans as required to be reserved in a Panchayat Samiti or in a Zila Parishad area for persons belonging to SCs, STs, or Backward Classes and women in accordance with the provisions of Sec. 16 of the Act. (2) The number of offices of Sarpanchas and Pradhans so reserved for SCs, STs, and OBCs shall be allocated by the Officer authorised by the Government to different Panchayats or Panchayat Samitis, as the case may be, by following the procedure as laid down in Rule 7. (3) The Officer authorised by the Government shall determine by draw of lots the offices of Sarpanchas and Pradhans to be reserved in the district for women.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Rule 10 — Reservation of offices of Pramukhs (Zila Pramukh)
(1) The Government shall determine the number of offices of Pramukhs to be reserved for SCs/STs/OBCs and Women. (2) The number of offices of Pramukhs reserved for SCs and STs shall be allocated by the Government to different districts by arranging them in descending order of the percentage of population of SCs or STs separately, excluding such districts where percentage of population of SCs or STs is less than five, and by following the procedure as laid down in Rule 7. (3) After having determined the offices of Pramukhs for SCs and STs, the Government shall allocate the offices of Pramukhs reserved for Backward Classes by drawing lots out of the remaining districts. (4) (a) One office of Pramukh out of the total number of offices of Pramukhs reserved for women shall be allocated to each Division as constituted under the Rajasthan Land Revenue Act, 1956 (Act No. 15 of 1956). The offices so allotted to a Division shall further be allocated by draw of lots to a District in the Division by the Government. (b) The remaining number of offices reserved for women shall be allocated by the Government by draw of lots to the districts remaining after the allocation under Clause (a). (5) The offices of Pramukhs reserved in the State for Backward Classes and Women by draw of lots in the first general election, shall be excluded while drawing lots for such reservation in the succeeding elections till the cycle is completed.
_Note:_ This is the exact machinery that produced the 13.08.2026 Zila Pramukh lottery results below: SC/ST districts by descending population order, OBC by lot among the rest, one women's-office guaranteed per Revenue Division then remaining women's offices by lot.
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1129_00001_00001_1563516015325&type=rule&filename=the_rajasthan_panchayati_raj_%28election%29_rules%29%2C_1994.pdf

### Act 13 of 1994, Section 15 — Reservation of Seats (full, with amendment history)
15. Reservation of Seats.- (1) Seats to be filled by direct election in a Panchayati Raj Institution shall be reserved for - (a) the Scheduled Casts; (b) the Scheduled Tribes; (c) the Backward Classes, as also for women in accordance with the provisions contained in the succeeding sub-sections. (2) The number of seats reserved for the Scheduled Castes and the Scheduled Tribes, shall bear, as nearly as may be, the same proportion to the total number of seats to be filled by direct election in Panchayati Raj Institution as the population of such Castes or, as the case may be, such Tribes in that Panchayati Raj Institution area bears to the total population of the area. (3) Such percentage, not exceeding [twentyone], of seats in a Panchayati Raj Institution at each level shall be reserved for Backward Classes as the percentage of the combined rural population of Scheduled Castes and Scheduled Tribes in the concerned district in relation to the total rural population of the district falls short of fifty: Provided that at least one seat shall be reserved in each Panchayati Raj Institution at each level for Backward Classes where the combined rural population of Scheduled Castes and Scheduled Tribes in the concerned district does not exceed seventy percent of the total rural population of the district. (4) Seats reserved in accordance with the provisions contained in the preceding sub-sections may be allotted by rotation to different wards or, as the case may be different constituencies in the concerned Panchayat Raj Institution; (5) Not less than one-third of the total number of seats reserved under Sub-sec. (2) and (3) shall be reserved for women belonging to the Scheduled Castes, the Scheduled Tribes or, as the case may be, the Backward Classes. (6) Not less than one-third (including the number of seats reserved for women belonging to the Scheduled Castes, the Scheduled Tribes and the Backward Classes) of the total number of seats to be filled by direct election in every Panchayati Raj Institution shall be reserved for women and such seats may be allotted by rotation to different wards or, as the case may be, constituencies in the concerned Panchayati Raj Institution in such manner as may be prescribed.
_Note:_ Statutory floor is 'not less than one-third' for women (Ss.15(5)/(6)); the 2026 circular's 50% instruction (para 4(v) above) exceeds this floor as current state policy.
_Source:_ https://prsindia.org/files/bills_acts/acts_states/rajasthan/1994/Act%20No.%2013%20of%201994%20RJ.pdf

### Act 13 of 1994, Section 16 — Reservation of the offices of Chairpersons (full, with amendment history)
16. Reservation of the offices of Chairpersons.- (1) The offices of the Sarpanchas, the Pradhans and the Pramukhs shall be reserved for - (a) the Scheduled Castes; (b) the Scheduled Tribes; (c) the Backward Classes; as also for women in accordance with the provisions contained in the succeeding sub-sections. (2) The number of each of such offices reserved for the Scheduled Castes and the Scheduled Tribes shall bear, as nearly as may be, the same proportion to the total number of each of such offices in the State as the population of such Castes, or as the case may be, such Tribes in the State bears to the total population of the State. (3) Such percentage, not exceeding [twentyone] of offices of Sarpanch or Pradhan in a Panchayat Samiti or Zila Parishad, as the case may be, shall be reserved for Backward Classes, as the percentage of the combined population of Scheduled Castes and Scheduled Tribes in the Panchayat Samiti or Zila Parishad or Zila Parishad area, as the case may be, falls short of fifty: Provided that at least one office of Sarpanch or Pradhan in a Panchayat Samiti or Zila Parishad shall be reserved for Backward Classes where the combined population of Scheduled Castes and Scheduled Tribes in the Panchayat Samiti or Zila Parishad area, as the case may be, does not exceed seventy per cent of the total population of the Panchayat Samiti or Zila Parishad area. (4) [twentyone] per cent of the total number of offices of Pramukh in the State shall be reserved for the Backward Classes. (5) Not less than one-third of the total number of offices of Sarpanchas, Pradhans and Pramukhs in the State shall be reserved for women. (6) Offices reserved under this section shall be allotted by rotation to different Panchayats, Panchayat Samiti and Zila Parishad in the State in such manner as may be prescribed. Explanation.- If a fraction forms part of the number of seats computed under Sec. 15 of offices computed under this section, the number of seats or offices, as the case may be, shall be increased to the next higher number in case the fraction consists of half or more of a seat or office and the fraction shall be ignored in case it consists of less than half of a seat or office.
_Note:_ S.16(6) 'in such manner as may be prescribed' -> operationalised by Rules 9-10 above and by the 2026 circular's para 4(ii)/(iii) 'existing cycle continues' instruction.
_Source:_ https://prsindia.org/files/bills_acts/acts_states/rajasthan/1994/Act%20No.%2013%20of%201994%20RJ.pdf

### Press release, PRD Rajasthan, 13.08.2026 — Zila Pramukh reservation lottery, verbatim district-wise result
जयपुर, 13 अगस्त। पंचायती राज संस्थाओं के आम चुनाव-2026 की तैयारियों के क्रम में गुरुवार को जयपुर स्थित इंदिरा गांधी पंचायती राज संस्थान में जिला प्रमुखों के पदों के आरक्षण की लॉटरी प्रक्रिया संपन्न हुई। लॉटरी प्रक्रिया शासन सचिव एवं आयुक्त, पंचायती राज विभाग डॉ. जोगाराम की अध्यक्षता में निर्धारित कार्यक्रम के अनुसार आयोजित की गई। राजस्थान की सभी 41 जिला परिषदों के लिए जिला प्रमुख पदों का श्रेणीवार आरक्षण लॉटरी के माध्यम से निर्धारित किया गया। निर्धारित आरक्षण एवं रोटेशन व्यवस्था के तहत ओबीसी वर्ग के लिए 5 पद आरक्षित किए गए, जिनमें ब्यावर एवं सीकर में महिला जिला प्रमुख का पद आरक्षित हुआ। इसी प्रकार अनुसूचित जाति (एससी) वर्ग के लिए 8 पद आरक्षित किए गए, जिनमें दौसा, भरतपुर, टोंक एवं धौलपुर में महिला जिला प्रमुख का पद निर्धारित हुआ। अनुसूचित जनजाति (एसटी) वर्ग के लिए 7 पद आरक्षित किए गए, जिनमें सलूम्बर, प्रतापगढ़ एवं अलवर में महिला जिला प्रमुख का पद आरक्षित हुआ। सामान्य महिला के लिए चूरू, अजमेर, झुंझुनू, चित्तौड़गढ़, हनुमानगढ़, डीग, श्रीगंगानगर, झालावाड़, फलोदी, बीकानेर एवं कोटा जिला परिषदों के जिला प्रमुख पद निर्धारित किए गए। वहीं बारां, बाड़मेर, भीलवाड़ा, जयपुर, जोधपुर, करौली, कोटपूतली-बहरोड़, राजसमंद, सिरोही एवं उदयपुर जिला परिषदों के जिला प्रमुख पद अनारक्षित रहे। शासन सचिव डॉ. जोगाराम ने कहा कि लॉटरी प्रक्रिया में आरक्षण के निर्धारित प्रावधानों एवं रोटेशन व्यवस्था का पूर्णतः पालन करते हुए जिला प्रमुखों के पदों का श्रेणीवार निर्धारण किया गया है। पंचायती राज संस्थाओं के आम चुनाव में सामान्य, ओबीसी, एससी एवं एसटी सभी श्रेणियों में महिलाओं के लिए 50 प्रतिशत आरक्षण का प्रावधान लागू रहेगा। उन्होंने बताया कि पूरी लॉटरी प्रक्रिया पारदर्शी तरीके से निर्धारित नियमों एवं प्रावधानों के अनुरूप संपन्न कराई गई। प्रक्रिया की वीडियोग्राफी भी कराई गई, ताकि इसका संपूर्ण रिकॉर्ड सुरक्षित रखा जा सके। लॉटरी प्रक्रिया में राजनीतिक दलों के प्रतिनिधि, अधिकारीगण, पत्रकार एवं आमजन उपस्थित रहे।
_Note:_ This is the district-wise category-counts result for Zila Pramukh (41 ZPs): OBC=5 (women: Beawar, Sikar), SC=8 (women: Dausa, Bharatpur, Tonk, Dholpur), ST=7 (women: Salumbar, Pratapgarh, Alwar), General-Women=11 (Churu, Ajmer, Jhunjhunu, Chittorgarh, Hanumangarh, Deeg, Sri Ganganagar, Jhalawar, Phalodi, Bikaner, Kota), Unreserved=10 (Baran, Barmer, Bhilwara, Jaipur, Jodhpur, Karauli, Kotputli-Behror, Rajsamand, Sirohi, Udaipur). Total 5+8+7+11+10=41. It is a press release, not the formal signed order/notification itself — that formal order was not separately located on the department portal at time of research (see gaps).
_Source:_ https://rajpanchayat.rajasthan.gov.in/home/press-release/249349

### SEC Order No. F.7(1)(1)/पंचा/रानिआ/2024/853, dated 23.01.2026, para 2 (polling-booth rule cross-reference)
राजस्थान पंचायतीराज (निर्वाचन) नियम, 1994 के नियम 30 के अनुसार जिला निर्वाचन अधिकारी के निर्देशों के अध्यधीन रहते हुए मतदान केन्द्रों/बूथों का चयन निर्वाचन अधिकारी द्वारा किया जाता है।
_Note:_ Not a reservation clause, but the SEC's own citation of Rule 30 for polling-booth siting, included per the brief's instruction to pull SEC circulars/orders governing the 2026 general election.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/853.pdf


## PRIOR-CYCLE / CASE LAW

### Constitution of India, Art. 243D
243 D. Reservation of seats.- (1) Seats shall be reserved for -
(a) the Scheduled Castes; and
(b) the Scheduled Tribes.
in every Panchayat and the number of seats so reserved shall bear, as nearly as may be, the same proportion to the total number of seats to be filled by direct election in that Panchayat as the population of the Scheduled Castes in that Panchayat area or of the Scheduled Tribes in that Panchayat area bears to the total population of that area and such seats may be allotted by rotation to different constituencies in a Panchayat.
(2) Not less than one-third of the total number of seats reserved under clause (1) shall be reserved for women belonging to the Scheduled Castes or, as the case may be, the Scheduled Tribes.
(3) Not less than one-third (including the number of seats reserved for women belonging to the Scheduled Castes and the Scheduled Tribes) of the total number of seats to be filled by direct election in every Panchayat shall be reserved for women and such seats may be allotted by rotation to different constituencies in a Panchayat.
(4) The offices of the Chairpersons in the Panchayats at the village or any other level shall be reserved for the Scheduled Castes, the Scheduled Tribes and women in such manner as the Legislature of a State may, by law, provide;
Provided that the number of offices of Chairpersons reserved for the Scheduled Castes and the Scheduled Tribes in the Panchayats at each level in any State shall bear, as nearly as may be, the same proportion to the total number of such offices in the Panchayats at each level as the population of the Scheduled Castes in the State or of the Scheduled Tribes in the State bears to the total population of the State:
Provided further that not less than one-third of the total number of offices of Chairpersons in the Panchayats at each level shall be reserved for women:
Provided also that the number of offices reserved under this clause shall be allotted by rotation to different Panchayats at each level:
(5) The reservation of seats under clauses (1) and (2) and the reservation of offices of Chairpersons (other than the reservation for women) under clause (4) shall cease to have effect on the expiration of the period specified in article 334.
(6) Nothing in this Part shall prevent the Legislature of a State from making any provision for reservation of seats in any Panchayat or offices of Chairpersons in the Panchayats at any level in favour of backward class of citizens.
_Note:_ Extracted verbatim from Part I of the SEC Manual (2014), which reproduces the Constitution text as in force.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj Act, 1994, s.15 (Reservation of Seats)
15. Reservation of Seats.- (1) Seats to be filled by direct election in a Panchayati Raj Institution shall be reserved for -
(a) the Scheduled Casts;
(b) the Scheduled Tribes;
(c) the Backward Classes,
as also for women in accordance with the provisions contained in the succeeding sub-sections.
(2) The number of seats reserved for the Scheduled Castes and the Scheduled Tribes, shall bear, as nearly as may be, the same proportion to the total number of seats to be filled by direct election in Panchayati Raj Institution as the population of such Castes or, as the case may be, such Tribes in that Panchayati Raj Institution area bears to the total population of the area.
(3) Such percentage, not exceeding [twentyone], of seats in a Panchayati Raj Institution at each level shall be reserved for Backward Classes as the percentage of the combined rural population of Scheduled Castes and Scheduled Tribes in the concerned district in relation to the total rural population of the district falls short of fifty :
Provided that at least one seat shall be reserved in each Panchayati Raj Institution at each level for Backward Classes where the combined rural population of Scheduled Castes and Scheduled Tribes in the concerned district does not exceed seventy percent of the total rural population of the district.
(4) Seats reserved in accordance with the provisions contained in the preceding sub-sections may be allotted by rotation to different wards or, as the case may be different constituencies in the concerned Panchayat Raj Institution;
(5) Not less than one-third of the total number of seats reserved under Sub-sec. (2) and (3) shall be reserved for women belonging to the Scheduled Castes, the Scheduled Tribes or, as the case may be, the Backward Classes.
(6) Not less than one-third (including the number of seats reserved for women belonging to the Scheduled Castes, the Scheduled Tribes and the Backward Classes) of the total number of seats to be filled by direct election in every Panchayati Raj Institution shall be reserved for women and such seats may be allotted by rotation to different wards or, as the case may be, constituencies in the concerned Panchayati Raj Institution in such manner as may be prescribed.
_Note:_ Cross-verified identical wording in the SEC Manual (2014), s.15 pp.58-59. NOTE: post-2008 amendment substituted 'One half' for 'One third' in the women's-reservation fractions in the parallel Election Rules; the Act text itself as reproduced in both PDFs still literally reads 'one-third' with amendment footnotes marking the 2000 (Act 9/2000) changes — the Manual's copy of the Rules (r.6) shows the 2008 'one half' substitution explicitly (see Rule 6 clause below).
_Source:_ https://prsindia.org/files/bills_acts/acts_states/rajasthan/1994/Act%20No.%2013%20of%201994%20RJ.pdf

### Rajasthan Panchayati Raj Act, 1994, s.16 (Reservation of the offices of Chairpersons)
16. Reservation of the offices of Chairpersons.- (1) The offices of the Sarpanchas, the Pradhans and the Pramukhs shall be reserved for -
(a) the Scheduled Castes;
(b) the Scheduled Tribes;
(c) the Backward Classes;
as also for women in accordance with the provisions contained in the succeeding sub-sections.
(2) The number of each of such offices reserved for the Scheduled Castes and the Scheduled Tribes shall bear, as nearly as may be, the same proportion to the total number of each of such offices in the State as the population of such Castes, or as the case may be, such Tribes in the State bears to the total population of the State.
(3) Such percentage, not exceeding [twentyone] of offices of Sarpanch or Pradhan in a Panchayat Samiti or Zila Parishad, as the case may be, shall be reserved for Backward Classes, as the percentage of the combined population of Scheduled Castes and Scheduled Tribes in the Panchayat Samiti or Zila Parishad or Zila Parishad area, as the case may be, falls short of fifty :
Provided that at least one office of Sarpanch or Pradhan in a Panchayat Samiti or Zila Parishad shall be reserved for Backward Classes where the combined population of Scheduled Castes and Scheduled Tribes in the Panchayat Samiti or Zila Parishad area, as the case may be, does not exceed seventy per cent of the total population of the Panchayat Samiti or Zila Parishad area.
(4) [twentyone] per cent of the total number of offices of Pramukh in the State shall be reserved for the Backward Classes.
(5) Not less than one-third of the total number of offices of Sarpanchas, Pradhans and Pramukhs in the State shall be reserved for women.
(6) Offices reserved under this section shall be allotted by rotation to different Panchayats, Panchayat Samiti and Zila Parishad in the State in such manner as may be prescribed.
Explanation.- If a fraction forms part of the number of seats computed under Sec. 15 of offices computed under this section, the number of seats or offices, as the case may be, shall be increased to the next higher number in case the fraction consists of half or more of a seat or office and the fraction shall be ignored in case it consists of less than half of a seat or office.
_Note:_ This is the enabling provision — 'in such manner as may be prescribed' — for the detailed rotation mechanics that are actually worked out in Rules 7, 9 and 10 of the Election Rules, 1994 (below).
_Source:_ https://prsindia.org/files/bills_acts/acts_states/rajasthan/1994/Act%20No.%2013%20of%201994%20RJ.pdf

### Rajasthan Panchayati Raj (Election) Rules, 1994, r.4 (Publication of wards or constituencies — the delimitation/nav-srijit step)
4. Publication of wards or constituencies.- (1) The wards or constituencies formed under rule 3 shall be notified by the Officer authorised by the Government by affixing statement thereof on the notice board of the office of the District Election Officer (Panchayats) and the office of Panchayat Samiti in respect of constituencies for Zila Parishads; on the notice board of the District Election Officer (Panchayats), the Panchayat Samiti, and Panchayats in respect of constituencies for Panchayat Samiti, and on the notice board of the Panchayat and a conspicuous place in every village of the Panchayat in respect of wards of the Panchayats.
(2) Any adult inhabitant of the Panchayat area/constituency may, if he objects to anything contained in the Statement affixed under sub-rule (1) pertaining to the ward or constituency related to the Panchayati Raj Institution of which he is a voter, submit his objection in writing to the Officer authorised by the Government within seven days from the date of affixing of such statement.
(3) All objections received under sub-rule (2) shall be affixed on the notice board of the office of the Officer authorised by the Government on the date of their receipt. After the time prescribed for receipt of objections is over, the Officer authorised by the Government under rule 4 (2) shall forward all the statement of wards/constituencies formed under rule 3 and the objections, if any, received under rule 4 (2) alongwith his comments thereon to the State Government.
(4) The State Government, or any Officer authorised by it, shall thereon consider the objection and other material before it including the comments of the Officer authorised by the State Government under sub-rule (2) and shall decide the objections and thereafter amend, if necessary, the statements accordingly, finally determine the wards and constituencies and shall notify the same by affixing the final statement of wards/constituencies...
_Note:_ Rule 4 is the delimitation/publication rule (not a rotation rule); it is the step the 2019 gram-panchayat reorganisation (Section 101 of the Act) had to run through before Rules 5-7 reservation could be redetermined — this is the statutory hook for 'नवसृजित ग्राम पंचायत' cases.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj (Election) Rules, 1994, r.5 (Reservation of seats for SC/ST/OBC)
5. Reservation of seats for Scheduled Castes/Scheduled Tribes and Other Backward Classes.- The number of wards or constituencies to be reserved for persons belonging to the Scheduled Castes/Scheduled Tribes or Other Backward Classes shall be determined by the Officer authorised by the Government in accordance with the provisions of the Act.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj (Election) Rules, 1994, r.6 (Reservation for Women)
6. Reservation for Women.- (1) [One half] of the seats reserved for the Scheduled Castes or the Scheduled Tribes or the Backward Classes shall be reserved for the women belonging to such Castes, Tribes or, as the case may be, Classes.
(2) [One half], including the number of seats reserved under sub-rule (1), of the total number of seats shall be reserved for women.
(3) The Officer authorised by the Government shall determine the seats to be reserved for women.
[Footnote: 'One half' substituted vide notification No. F.4(12)PRD/Legal/Rule/Amend/08/2362, dated 25-6-08 for the words 'One third'.]
_Note:_ Rajasthan raised women's quota from one-third to one-half (50%) by amendment dated 25.06.2008 — i.e. the 2010, 2015 and 2019-20 cycles all operated under the 50% formula, not the constitutional one-third floor.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj (Election) Rules, 1994, r.7 (Procedure for reservation — the core descending-order / lottery / rotation / exhaustion mechanic)
7. Procedure for reservation.- (1) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Scheduled Castes under section 15 of the Act, first identify the wards or constituencies which consist of population of the Scheduled Castes and such wards or constituencies shall be serially arranged in the descending order of percentage of population of Scheduled Castes. excluding the wards and constituencies where such percentage is less than five, and shall be assigned serial numbers as SC 1, SC 2 and so on.
(2) The serial numbers so assigned shall be known as special serial numbers for Scheduled Castes.
(3) The Officer authorised by the Government shall first allocate the number of seats reserved for SCs (including [One half] of such seats reserved for women belonging to the Scheduled Castes) serially to the wards bearing special numbers for Scheduled Castes.
(4) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Scheduled Tribes under section 15 of the Act, after the seats having been determined and allocated under the aforesaid section for SCs, proceed to identify the wards and constituencies which consist of population of Scheduled Tribes and such wards and constituencies shall be serially arranged in the descending order of percentage of population of Scheduled Tribes excluding the wards and constituencies where such percentage is less than five, and shall be assigned serial number as ST 1, ST 2 and so on.
(5) The serial number so assigned shall be known as special serial numbers for Scheduled Tribes.
(6) The Officer authorised by the Government shall, after having allocated the seats reserved for the Scheduled Castes under sub-rule (3), allocate the seats reserved for Scheduled Tribes (including [One half] of such seats reserved for women belonging to Scheduled Tribes) serially to the wards bearing special serial numbers for Scheduled Tribes.
(7) The Officer authorised by the Government shall for the purpose of reservation of seats for persons belonging to Backward Classes under section 15 of the Act, after having determined and allocated seats reserved for the persons belonging to the Scheduled Castes and the Scheduled Tribes (including [One half] of the seats reserved for women belonging to such Castes and Tribes), proceed further to allocate such number of seats in the Panchayati Raj Institutions as are required to be reserved for persons belonging to Backward Classes, (including one third of such seats reserved for women belonging to Backward Classes) out of remaining seats by lot.
(8) (a) The number of seats reserved for women belonging to the Scheduled Castes or the Scheduled Tribes or, as the case may be, the Backward Classes respectively shall be derived by dividing the seats to be reserved for the SCs or STs or as the case may be BCs by [two].
(b) If only one seat each is reserved for SC, ST or BC in any Panchayati Raj Institution, one seat out of the three as determined by draw of lots shall be reserved for women.
(9) The remaining number of seats reserved for women shall be determined by dividing the total number of seats by [two] and number so determined shall be reduced by the aggregate of the number of the seats derived for women belonging to the SCs, STs and BCs under sub-rule (8).
(10) The seats so reserved for women under rule 6 shall be allocated by lot.
(11) Where ever seats are to be reserved by draw of lots, the Officer authorised by the Government shall fix place, date and time for the purpose of drawing lots and inform the members of Legislative Assembly of the constituencies or part of the constituency falling in the district. The lots shall be drawn in accordance with the procedures laid down by the Government in the presence of such members of Legislative Assembly who may choose to be present at the appointed time.
(12) In every succeeding general election of the Panchayati Raj Institutions, the list of wards or constituencies bearing special serial number for Scheduled Castes or, as the case may be, Scheduled Tribes shall -
(i) continue to be operated serially from special serial number following the special serial number where the allocation of seats reserved for the SCs or, as the case may be, the STs has ended in the preceding election.
(ii) be operated till it is exhausted, and
(iii) be re-operated from the begining after it is exhausted.
(13) Wards and constituencies reserved for Backward Classes and women by draw of lots in the first general election shall be excluded while drawing lots for such reservation in succeeding elections till the cycle is completed.
_Note:_ This single rule answers most of the edge-case questions asked: SC/ST rotation runs off a fixed descending-order serial list that is picked up where the PRECEDING election left off (12)(i); when the list runs out it restarts from the top (12)(ii)-(iii) — i.e. the 'pool exhausted' answer is an explicit statutory restart, not a gap the department fills ad hoc. BC and (general) women reservation instead run on a lot-exclusion model — once-drawn units are excluded from future lots 'till the cycle is completed' (13), which is the textual basis for treating General-Women as a genuinely rotating/cycling category, distinct from the serial-list mechanism used for SC/ST. Sub-rule (8)-(9) shows SC/ST/BC-women seats are carved out of the SC/ST/BC allocation itself (i.e. a woman-reserved SC seat is allocated FROM the SC special-serial-number list under sub-rule 3/6), so structurally such a seat is tracked, for rotation purposes, as an 'SC' seat that happens to also be earmarked for a woman — the Rules do not provide a second, independent 'women's' serial list for SC/ST-women seats; only the residual/general-women and BC allocations get the separate lot-exclusion list under sub-rule (13).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj (Election) Rules, 1994, r.8 (Reservation for SCs or STs — the tie-break rule)
8. Reservation for SCs or STs.- Notwithstanding anything to the contrary contained in rule 6 and 7, where a ward or constituency becomes common to be reserved for SCs/STs, then it will be reserved for SCs or STs, as the case may be, which ever has higher percentage of SCs or STs.
Explanation :- While arranging wards or constituencies in descending order for the purpose of making reservation for persons belonging to SCs or STs, if a particular ward or constituency appears in both the lists, where the population of SCs is 14% and those of STs is 11%, in that case ward or constituency will be reserved for SCs.
_Note:_ This is the ONLY tie-break rule the Rules provide, and it is confined to an SC-vs-ST collision (resolved by higher population percentage, illustrated 14% vs 11%). The Rules contain no analogous express tie-break for a BC-vs-Women collision or any other category pairing — that is a genuine gap (see gaps list).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj (Election) Rules, 1994, r.9 (Reservation of offices of Sarpanchas and Pradhans)
9. Reservation of offices of Sarpanchas and Pradhans.- (1) The Officer authorised by the Government shall determine the number of offices of Sarpanchas and Pradhans as required to be reserved in a Panchayat Samiti or in a Zila Parishad area for persons belonging to SCs, STs, or Backward Classes and women in accordance with the provisions of section 16 of the Act.
(2) The number of offices of Sarpanchas and Pradhans so reserved for SCs, STs and OBCs shall be allocated by the Officer authorised by the Government to different Panchayats or Panchayat Samitis, as the case may be, by following the procedure as laid down in rule 7.
(3) The Officer authorised by the Government shall determine by draw of lots the offices of Sarpanchas and Pradhans to be reserved in the district for women.
_Note:_ Confirms that Sarpanch/Pradhan office rotation for SC/ST/OBC piggybacks on the same Rule 7 descending-order/serial-list mechanism as seats; the women's-office allocation is a separate draw-of-lots exercise under sub-rule (3), reinforcing that 'women' is tracked as its own rotating pool, not folded into the SC/ST/OBC serial lists at the OFFICE level either.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Rajasthan Panchayati Raj (Election) Rules, 1994, r.10 (Reservation of office of Pramukh)
10. Reservation of office of Pramukh.- (1) The Government shall determine the number of offices of Pramukhs to be reserved for SCs/STs/OBCs and women.
(2) The number of offices of Pramukhs reserved for SCs and STs shall be allocated by the Government to different districts by arranging them in descending order of the percentage of population of SCs or STs separately, excluding such districts where percentage of population of SCs or STs is less than five, and by following the procedure as laid down in rule 7.
(3) After having determined the offices of Pramukhs reserved for SCs and STs, the Government shall allocate the offices of Pramukhs reserved for Backward Classes by drawing lots out of the remaining districts.
(4) (a) One office of Pramukh out of the total number of offices of Pramukhs reserved for women shall be allocated to each Division as constituted under the Rajasthan Land Revenue Act, 1956, (Act No. 15 of 1956). The office so allotted to a Division shall further be allocated by draw of lots to a District in the Division by the Government.
(b) The remaining number of offices reserved for women shall be allocated by the Government by draw of lots to the districts remaining after the allocation under clause (a).
(5) The offices of Pramukh reserved in the State for Backward Classes and women by draw of lots in the first general election, shall be excluded while drawing lots for such reservation in the succeeding elections till the cycle is completed.
_Note:_ Mirrors Rule 7's SC/ST-serial-list vs BC/women-lot-exclusion split, but at Zila Parishad (Pramukh) level and district-wise rather than ward-wise.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/PS_Mannuals(new)_2014.pdf

### Virender Singh & Ors. vs. State of Rajasthan & Ors. (S.B. Civil Writ Petition No.1693/2020 & connected, Rajasthan HC Jodhpur, 26.02.2020, Arun Bhansali J.) — operative finding on reservation redraw after GP reorganisation
The redrawing of lottery pursuant to the orders dated 24/1/2020 issued by the State, resulted in earlier position getting changed, whereby, the wards which were either unreserved and/or were reserved for certain other categories, got reserved for some different category... The actuated action of the State is apparently in consonance with the provisions of Section 16 of the Act, 1994, which provides for reservation of the office of Chairpersons and Rule 7 of the Rules, 1994, which provides for procedure for reservation. The respondents have filed replies in most of the petitions, indicating the reasons for change and/or the requirement to redraw the lottery... Coming to the various challenges laid in the petitions to drawing of lottery/their justification on the grounds raised in the petition, the common thread by which the same have been dealt with by the State by filing reply in most of the matters is that the percentage of population of SC/ST in various Gram Panchayats got affected on account of notification issued subsequent to 15/16.11.2019, which resulted in variation in Gram Panchayat reserved for SC and the Gram Panchayat which was earlier reserved, getting dereserved and available for further reservation under the category pertaining to OBC and/or General (Women) it was necessary to undertake exercise for redrawing the lotteries for all the Gram Panchayats.
_Note:_ Directly on the 2019-2020 election cycle's newly-reorganised/delimited gram panchayats. Confirms the operative practice actually followed and judicially upheld: a change in SC/ST population share caused by reorganisation DE-reserves a unit from SC, sending it into the OBC and/or 'General (Women)' pool — i.e. General(Women) is treated as a live allocation category into which units flow, not a fixed residue. The Court upheld this as consonant with s.16 of the Act and r.7 of the Rules and dismissed all individual challenges to the redraw, including the specific Ashok Kumar (C.W. 1756/2020) plea that Sarpanch-lottery and Ward-Panch-lottery directions were followed 'vice versa' between Panchayat Samiti Dechu and Panchayat Samiti Lohawat (rejected as baseless since the State had left the final call to the SDO).
_Source:_ https://sec.rajasthan.gov.in/cm/upload/SB_Civil_Writ_16932020.pdf

### Virender Singh (supra) — restart-from-status-quo-ante holding
As status quo ante stood restored from before the draw of lotteries, the natural consequence thereof was to restart the process from the said stage based on the delimitation taking into consideration all the notifications and in those circumstances, it cannot be said that as the process pursuant to the notification dated 26/12/2019 had not been cancelled by the Election Commission the lotteries could not have been drawn has any substance.
_Note:_ Final operative order: 'the order passed by the State Election Commission dated 9/1/2020 and order passed by the State dated 24/1/2020 and subsequent orders thereto do not call for any interference. The individual challenges laid to the draw of lotteries also, for lack of any substance are rejected. Consequently, the writ petitions are dismissed.'
_Source:_ https://sec.rajasthan.gov.in/cm/upload/SB_Civil_Writ_16932020.pdf

### Jai Singh vs. State of Rajasthan & Ors. (D.B. Civil Writ Petition No.17993/2019 & connected, Rajasthan HC Jodhpur DB, 13.12.2019, Mahanty CJ & Bhati J.) — final holding on delimitation notifications
In view of the aforesaid observations, while dismissing all the issues pertaining to non-consideration of representations/non-consideration of recommendations/changes made in recommendations/changes made by the Sub Committee/changes not considered by the Sub Committee/not considered in the proposals/not considered by the District Collectors are held to be not maintainable, as this Court draws a strict line while adhering to the precedent laws of State of U.P. & Ors. Vs. Pradhan Sangh Kshettra Samiti & Ors. (supra) and Bhupendra Pratap Singh Rathore Vs. State of Rajasthan & Ors. (supra)... Thus, the petitions are dismissed as far as the pre-proceedings to the notification dated 15/16.11.2019 are concerned. However, at the same time, this Court is of the considered opinion that such golden line prescribed by the Constitution of India read with Section 101 of the Act of 1994 cannot be crossed by the State as it will amount to abuse of process of law, as the delimitation exercise cannot be an ever continuing exercise, and the same has to be completed in one procedure, spanning between the initial notice which in this case was dated 12.06.2019 to the final notification which was 15/16.11.2019 and has to be brought to an end then and there. It cannot be an ever continuing exercise, as it shall jeopardize the sanctity of the mandate of the Constitution, and thus, all the notifications subsequent to the notification dated 15/16.11.2019, pertaining to the issue in question, stand quashed and set aside, except for the notifications which are purely rectifying the typographical errors.
_Note:_ This is the underlying delimitation ruling that triggered the reservation redraw litigated in Virender Singh. It also holds (para on Section 101) that judicial review of the delimitation/reorganisation NOTICE-and-objection process itself is barred once the final notification issues, by Article 243-O read with Section 101 — objections to formation of a 'नवसृजित' gram panchayat must be raised at the Tehsildar/SDO/Collector stage, not by writ after the fact.
_Source:_ https://sec.rajasthan.gov.in/cm/upload/Mangilal_Vs_State_of_Raj_DB_Civil_Writ_No_17731_2019.pdf


### Rajasthan Municipalities (Election) Rules, 1994 — Rule 5 (Reservation of reserved wards), VERBATIM (fetched 16.08.2026 10:30 IST from India Code)
_Source:_ https://upload.indiacode.nic.in/showfile?actid=AC_RJ_83_1125_00001_00001_1612524193363&type=rule&filename=the_rajasthan_municipalities_(election)_rules,_1994.05.24.pdf (20 pp; pdftotext -layout)
_Note:_ **No 5% minimum-population threshold anywhere in Rule 5** — sub-rules (2) and (5) say "identify the wards which consist of the population of the Scheduled Castes/Tribes and such wards shall be serially arranged in the descending order of percentage" with no exclusion clause (contrast Panchayat r.7(1)/(4) "excluding the wards … where such percentage is less than five"). Women = one-third throughout (5(4), 5(7), 5(10), 5(11)); common ward → higher percentage (5(8)); serial-list continuation in succeeding elections (5(9)); OBC by lot to remaining wards (5(10)); women's wards by lot (5(11)); notice to MLAs of constituencies covering the municipality AND recognised political parties (5(12) + Explanation: Symbols Order 1968); BC/women lot exclusion till cycle completed (5(13)); subject to rule 3 (5(14)). Consequence for चक्र: ULB threshold OFF (as text); cite r.5(2)–(8) for descending order/r.8-equivalent, r.5(10)/(11) for lots, r.5(12) for notice.

```
5. Reservation of reserved wards. - (1) The number of wards to be reserved for Scheduled
     Castes/Scheduled Tribes/Backward Classes and also for women shall be determined by
     the Officer, in accordance with the provisions of Act.
(2) The Officer shall for the purpose of reservation of seats for Scheduled Castes, first
     identify the wards which consist of the population of the Scheduled Castes and such
     wards shall be serially arranged in the descending order of percentage of population of
     Scheduled Castes, and shall be assigned serial number as S.C. 1, S.C. 2 and so on.
(3) The serial number so assigned shall be known as special serial number for Scheduled
     Castes.
(4) The Officer shall allocate the number of seats reserved for Scheduled Castes (including
     one-third of such seats reserved for women, belonging to Scheduled Castes) serially to
     the wards bearing special serial number for Scheduled Castes.
(5) The Officer shall also for the purpose of reservation of seats for Scheduled Tribes,
     proceed to identify the wards which consist of population of Scheduled Tribes and such
     wards shall be serially arranged in the descending order of percentage of population of
     Scheduled Tribes and shall be assigned serial number as S.T. 1, S.T. 2 and so on.
(6) The serial number so assigned shall be known as special serial number for Scheduled
     Tribes.
(7) The Officer shall also allocate the seats reserved for Scheduled Tribes (including one-
     third of such seats reserved for women belonging to Scheduled Tribes) serially to the
     wards bearing special serial number for Scheduled Tribes.
(8) Where a ward becomes common to be reserved for Scheduled Castes & Scheduled
     Tribes, then it will be reserved for Scheduled Castes or Scheduled Tribes, as the case
     may be, whichever, has higher percentage of Scheduled Castes or Scheduled Tribes.
(9) In every succeeding general election, the list of wards bearing special serial number for
     Scheduled Castes, or, as the case may be. Scheduled Tribes shall-
    (i) continue to be operated serially from special serial number following the special serial
        number, where the allocation of sets reserved for the Scheduled Castes or, as the
        case may be, the Scheduled Tribes had ended in the preceding election.
    (ii) be operated till it is exhausted,and
    (iii) be re-opened from the beginning after it is exhausted.
(10) The Officer, after having determined and allocated seats reserved for Scheduled Castes
      and Scheduled Tribes, shall allocate the number of seats reserved for Backward
      Classes (including one-third seats reserved for women belonging to Backward Classes),
      to remaining wards by draw of lots.
(11) The wards to be reserved for women shall be one third of total number of wards in a
      municipality to be determined by draw of lots by the Officer.
(12) Wherever seats are to be reserved by draw of lots the officer shall fix the place, date
      and time for the purpose of drawing lots and inform the members of the Legislative
      Assembly representating a constituency which comprises wholly or partly the area of the
      municipality, and the recognised political parties in the State of Rajasthan. The lots shall
      be drawn in the manner as determined by the officer in the presence of such members
      of the Legislative Assembly or the nominees of the recognised political parties who may
      be present at the appointed time.
Explanation. - For the purpose of this rule and the succeeding rules, recognised political
   parties means the political parties recognised in State as such under the Election
   Symbols (Reservation and Allotment) Order, 1968.
(13) Wards reserved for Backward Classes and women by draw of lots in the first general
   election shall be excluded while drawing lots for such reservation in succeeding elections
   till the cycle is completed.
(14) The provisions of sub-rule (1) to (13), shall be subject to the provisions of rule 3.
```


### DLB order F.10(नपा)(चुनाव)(जन)/डीएलबी/2026/23435, dated 16.08.2026 — SUPERSEDES letter 23434 (14.08.2026); eight points on ULB ward reservation under Municipal (Election) Rules r.5
_Source:_ scan (3 pp, digitally signed 16.08.2026 14:29), filed at data/dausa/sources/prapatra-kha/circulars/dlb-order-23435-2026-08-16-supersedes-23434.pdf — text below is a faithful SUMMARY of the Hindi table, not a transcription.
पत्र क्रमांक एफ.10(नपा)(चुनाव)(जन)/डीएलबी/2026/23435 दिनांक 16.08.2026 (स्वायत्त शासन विभाग; पत्र 23434 दिनांक 14.08.2026 को अतिक्रमित करते हुए) — नगरपालिका (निर्वाचन) नियम 1994 के नियम 5 के अंतर्गत वार्ड आरक्षण के आठ बिंदु: (1) परिसीमन में वार्ड-संख्या/वार्ड नम्बर/निकाय सीमा/वार्ड सीमा में कोई परिवर्तन नहीं → 2019-20 में आरक्षित वार्ड अपवर्जित कर आरक्षण आगे चक्रीय क्रम (Rotational Order) में; (2) वार्ड-संख्या यथावत, समस्त वार्डों की आंतरिक सीमा बदली → सभी वर्गों में नये सिरे से; (3) वार्ड-संख्या यथावत, आंशिक वार्डों की आंतरिक सीमा बदली → यदि SC/ST वार्डों के नम्बर यथावत हैं तो 2019-20 में आरक्षित वार्ड अपवर्जित कर शेष वार्डों को अवरोही क्रमानुसार पूर्व के चक्रानुसार आरक्षण; OBC व महिला के 2019-20 में आरक्षित वार्ड अपवर्जित कर इन वर्गों हेतु लॉटरी; (4) निकाय सीमा में वृद्धि, वार्ड-संख्या यथावत, समस्त वार्डों की सीमा बदली → नये सिरे से सभी वर्गों में; (5) निकाय सीमा में वृद्धि, वार्ड-संख्या यथावत, पुराने वार्डों में आंशिक परिवर्तन → पूर्व के यथावत वार्डों में SC/ST वार्ड हों तो 2019-20 में आरक्षित वार्ड अपवर्जित कर शेष वार्डों के साथ शामिल कर जनसंख्या के अवरोही क्रमानुसार पूर्व के चक्रानुसार; OBC व महिला वर्ग के 2019-20 वार्ड अपवर्जित कर शेष के साथ शामिल कर लॉटरी; (6) निकाय सीमा में वृद्धि, पुराने वार्ड अपरिवर्तित, केवल नये क्षेत्र में नये वार्ड → 2019-20 के SC/ST वार्ड अपवर्जित कर नवीन SC/ST वार्डों एवं 2019-20 के चक्र में शेष रहे वार्डों को जनसंख्या के अवरोही क्रम में व्यवस्थित कर पूर्व चक्र के अनुसार आरक्षण; OBC व महिला के 2019-20 वार्ड अपवर्जित कर नवीन वार्डों व शेष चक्र-वार्डों में से लॉटरी; (7) महिलाओं का आरक्षण कुल वार्डों के आधार पर ⅓ या प्रत्येक वर्गवार ⅓ → वर्गवार ⅓; (8) वार्ड-संख्या/सीमा में कोई परिवर्तन नहीं, केवल वार्ड नम्बर बदले → विभिन्न वर्गों में आरक्षण पूर्व चक्रानुसार। — स्कैन (सार); मूल PDF: data/dausa/sources/prapatra-kha/circulars/dlb-order-23435-2026-08-16-supersedes-23434.pdf
_Note:_ Effect on the engine: the ⅓-of-wards test of 23434 is gone; "fresh in all categories" only for cases 2 and 4 (ALL wards' internal boundaries changed); cases 1/3/5/6/8 = continue — exclude the 2019-20 reserved wards (SC/ST from the descending list; OBC/women from the lots), rank/lot the rest "per the earlier cycle". Point 7 confirms women ⅓ PER CATEGORY (as अधिसूचना 23401). Dausa: 7 new bodies unaffected (no 2019-20 history); लालसोट/दौसा/बांदीकुई/महवा need the EO's case certificate; लालसोट (DLB 113-list, district found ">⅓ changed" on 15.08) is most likely case 3 → continue.
