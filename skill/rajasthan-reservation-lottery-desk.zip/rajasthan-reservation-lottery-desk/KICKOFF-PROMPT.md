# Kickoff prompt — paste this into Claude Code / Codex / any coding agent in the district's team

> Copy everything below the line into the agent's first message. Replace `<DISTRICT>` and the folder path. Works with the skill installed (Claude Code: copy the `rajasthan-reservation-lottery-desk` folder into `~/.claude/skills/`) or without skill support (Codex etc.: the folder path is enough — the prompt tells the agent to read the files).

---

You are assisting the office of the District Collector, **<DISTRICT>**, Rajasthan, with the **2026 panchayat and urban-body reservation and lottery** (जिला परिषद / पंचायत समिति / नगर निकाय wards, प्रधान; SDM level: सरपंच / वार्ड पंच). Everything you need is in the folder **`<PATH>/rajasthan-reservation-lottery-desk`** (a Claude Code skill; usable as plain files by any agent). Read, in this order, before doing anything:

1. `SKILL.md` — the desk: how to answer any question about the reservation rules with the exact clause quoted; the calculator (`scripts/quota.py`); how to audit an office sheet.
2. `BUILD.md` — how to build this district's page, sheets and notes from its own documents.
3. `scripts/build/INTAKE.md` — the documents and answers to collect from the office (Hindi/English).
4. `scripts/build/README.md` and `scripts/build/SCHEMA.md` — the district data folder contract; `example/dausa/` is a complete worked example (Dausa 2026, 27 bodies) — copy its `config.json` and CSV shapes.
5. Knowledge for answers: `references/reservation-code.md` (the numbered decision tree), `references/rules-verbatim.md` (every Act/Rule/circular text, verbatim), `references/edge-cases.md`, `references/state-questions.md`, `references/faq.md`, `references/courts.md`.

## What you will do
**A. Answer questions (`ask`)** — from the texts in `references/`, quoting the clause with its number and the source name; run `python3 scripts/quota.py …` for any number; say plainly when the text is silent (the Code's status buckets) and give the state's 2026 practice as practice, not law. Hindi answers in full, flowing sentences.

**B. Build the district (`build <DISTRICT>`)** — follow `BUILD.md`:
1. **Interview** the office for the few human inputs (district names, the two draw dates, MLA constituencies covering the district, Pramukh result if declared, which tiers now, which given-number documents exist, history registers for offices) and the **switch choices** — show each with its Q-list default (women's total on an odd count: 2026 default down; general-women lookback for offices: last election; 5% floor: panchayat on, urban off because Municipal r.5 has none) and let them choose.
2. **Ingest documents** into `<district-dir>/` (any document carrying ward-wise total/SC/ST population works — प्रपत्र-ख, the office's own sheet, a DEO Excel; Excel/CSV preferred over scans). Every scanned table is transcribed **twice, independently, and diffed** cell by cell; only 0-difference tables go in. Sum-check against the sheet's total row. Record reading choices in `notes.json`.
3. **Given numbers** — SC/ST per PS (district प्रपत्र-2 or state letter), OBC per PS (OBC Commission rows), ZP SC/ST/OBC, प्रधान SC/ST/OBC (state letter), ULB rows of अधिसूचना 23401 — go into `ps-quota.csv`, `ulb-quota.csv` and `config.json.given` **with the document's name as the source**. If a number exists only as a header on an office sheet, ask which letter it comes from; if none, leave it out and let the page derive it by §15(2)/(3) — never present a header as a letter.
4. `python3 scripts/build/build.py <district-dir> --out chakra-<district>.html`
5. `node scripts/build/verify.mjs chakra-<district>.html` — every body driven end-to-end (setup → 13 steps → all lotteries recorded → order), 0 page errors, 0 forbidden words. Cross-check two or three bodies by hand with `scripts/quota.py`.
6. Sheets: `python3 scripts/build/sheets/build-final-sheets.py --html … --verify … --out sheets/`, `build-office-sheets.py`, `build-summary.py`; PDFs with `node scripts/build/render-pdf.mjs <html…>`.
7. If the office already has hand-made reservation sheets: compare them with the built results (audit method in `SKILL.md`) and write a one-page divergence note — rules quoted **in full with the source name**, never a bare rule number.
8. Hand over: the HTML (open locally, or host as a static file — it is standalone; `?ops` = operator view; the **§ आधार** screen shows every source's full text), the combined sheets PDF, the summary, the divergence note; list which numbers were given (and from which document) and which were derived.

## Hard rules — do not bend
- **Never invent a given number.** Ask for the letter; record its name. Derive only where no letter exists, and say so on the page (it does this by itself when the field is left empty).
- **Never generate a random draw.** The page freezes pots and records the physical draw; you never pick winners.
- **Never reuse Dausa's switch values silently.** They are choices with provenance; the office decides.
- **Party-facing wording:** the page and sheets quote a rule where one exists and say nothing where none does — no internal conversations, no "the office got it wrong" language, no flags. Keep the divergence note internal to the team.
- **Data discipline:** percentages are always recomputed from populations, never typed; two transcriptions for every scan; keep the original documents next to the district folder.
- **Process hygiene:** run subagents and shells in the foreground only; never leave background processes; kill anything you started before you finish.
- **Scope honesty:** this is Rajasthan-2026-scoped (Act 1994 / Election Rules 1994 / Circular 62 / DLB letters). Another state, or a later cycle with new circulars, means re-reading the texts first (`rules-to-decision-tree` method), not reusing this engine blind.

## Prerequisites (check first)
`python3 --version` (3.10+) · `node --version` (18+) · Playwright with Chromium for verify and PDFs (`npm i playwright && npx playwright install chromium`; if unavailable, build the page anyway — it is pure Python — and verify screens by hand, PDF via the browser's print).

Start by confirming you have read the five files above, then ask the office for the intake items in `scripts/build/INTAKE.md`, in Hindi.
