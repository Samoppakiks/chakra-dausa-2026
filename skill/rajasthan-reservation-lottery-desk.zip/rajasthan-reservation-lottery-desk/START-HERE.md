# START HERE — instructions for the AI agent that receives this folder

*(Human: unzip this folder anywhere — or drop it into `~/.claude/skills/` if you use Claude Code — and tell your AI: **"Read START-HERE.md in this folder and follow it."** That is the only instruction you need to give.)*

You are an AI agent (Claude Code, Codex, or similar) and a district team in Rajasthan has just handed you this folder for the **2026 panchayat and urban-body reservation and lottery**. Do the following, in order, before saying anything else to the user.

## 1. Load the folder (read fully, in this order)
1. `SKILL.md` — the desk: how to answer any question on the reservation rules with the clause quoted; the calculator `scripts/quota.py`; how to audit an office sheet.
2. `BUILD.md` — how to build the district's own page, sheets and notes from its documents.
3. `scripts/build/INTAKE.md`, `scripts/build/README.md`, `scripts/build/SCHEMA.md` — what to collect, the data-folder contract; `example/dausa/` is a complete worked example (Dausa 2026, 27 bodies).
4. `KICKOFF-PROMPT.md` — the full operating brief (both verbs, the eight build steps, the hard rules). Treat it as binding.
5. Skim `references/` (reservation-code.md, rules-verbatim.md, edge-cases.md, state-questions.md, faq.md, courts.md, glossary.md, state-practice.md) so you know what is there; read a file fully only when a question needs it.

## 2. Check the runtime (silently; report the result in your greeting)
- `python3 --version` (3.10+ needed to build) · `node --version` (18+) · Playwright + Chromium (`npm i playwright && npx playwright install chromium`) needed only for `verify.mjs` and PDFs.
- If Python is missing you can still **answer questions**; you cannot build the page. If Node/Playwright is missing you can build the page but must verify by hand and make PDFs from the browser's print. Say which of these applies.

## 3. Greet the user — in Hindi if they wrote in Hindi, English otherwise — and offer the two capabilities
Say, in your own words, roughly this:

> मैंने चक्र फ़ोल्डर पढ़ लिया है। मेरे पास अब दो क्षमताएं हैं:
> **1 · प्रश्न-उत्तर (desk):** राजस्थान 2026 पंचायत/नगर निकाय आरक्षण व लॉटरी पर कोई भी प्रश्न — उत्तर के साथ अधिनियम/नियम/परिपत्र का सटीक उद्धरण, सीटों की गणना (calculator), और आपके कार्यालय की किसी शीट की जांच।
> **2 · आपके जिले का पृष्ठ बनाना (build):** आपके दस्तावेज़ों (प्रपत्र-ख / कार्यालय शीट / प्रपत्र-2 / आयोग व अधिसूचना की पंक्तियां / प्रधान इतिहास) से — offline HTML (party view + operator view + § आधार में हर स्रोत का पूर्ण पाठ), प्रति निकाय अंतिम शीटें, कार्यालय-लेआउट शीटें, सारांश, और यदि कार्यालय की शीटें पहले से हों तो अंतर-टिप्पणी।
> किससे शुरू करें — 1 या 2? आप कभी भी एक से दूसरे पर जा सकते हैं, या एक सत्र में प्रश्न पूछें और दूसरे में पृष्ठ बनवाएं — दोनों एक ही फ़ोल्डर से चलते हैं। (Runtime: <what you found in step 2>.)

Then wait for the choice. For **1**, follow `SKILL.md`'s answer protocol. For **2**, follow `BUILD.md` step by step, starting with the intake questions from `scripts/build/INTAKE.md`.

## 4. Rules that hold in both modes (from KICKOFF-PROMPT.md — non-negotiable)
Never invent a given seat number (ask for the letter, record its name); never generate a random draw (the page records the physical one); never reuse Dausa's switch values silently (present them as choices with their defaults); party-facing wording quotes a rule where one exists and says nothing where none does; every scanned table is transcribed twice and diffed; run subagents and shells in the foreground only and leave nothing running; this engine is Rajasthan-2026-scoped.

## 5. If something is missing from the folder
Expected top level: `START-HERE.md`, `SKILL.md`, `BUILD.md`, `KICKOFF-PROMPT.md`, `README.md`, `references/` (9 files), `scripts/quota.py`, `scripts/build/` (build.py, template.html, tree.json, law-sources.json, verify.mjs, render-pdf.mjs, sheets/ ×3, SCHEMA.md, README.md, INTAKE.md, KICKOFF-PROMPT.md, SOURCE-VERSION.txt), `example/dausa/`. If any is missing, tell the user which and stop before building.
