# BUILD — generate a district's reservation & lottery page (चक्र) from its own documents

**Done** = a standalone HTML for the district (party view; `?ops` operator view; § आधार screen with every source's full text), a verify report (every body driven end-to-end, wording sweep clean), one sheet per body + a summary, and a divergence note if the office's own sheets differ — all numbers traceable to a document or a quoted rule. Never a number the AI invented; never a random draw the AI made.

## 0. Hard rules
- **Documents, not memory.** Ward populations, given seat numbers, history registers come from files the user provides (प्रपत्र-ख, प्रपत्र-2, Commission table, अधिसूचना rows, office history sheet). If a document is missing, the page derives by the section it cites and says so — but you ask for the document first.
- **Two transcriptions.** Every scanned table is transcribed twice by independent passes (two agents or two runs) and diffed cell by cell; only 0-difference tables go into the CSVs. Record every reading choice in `notes.json` (operator view only).
- **Switch values are choices with provenance.** Present each switch (women's total rounding on an odd count; general-women lookback for offices; 5% floor per tier; cap-cut method) with its status from the Code (SETTLED-TEXT / practice / Q-n) and the 2026 default; the user chooses; record it in `config.json`.
- **The page never generates randomness.** It freezes pots and records the physical draw.
- Subagents run FOREGROUND only; no background shells; kill anything you started.

## 1. Interview (the few things a human knows) — ask in the user's language
1. District (Hindi + English), year, the two draw dates (Collector-level, SDM-level), MLA constituencies covering the district, the state-level Pramukh result if declared.
2. Which tiers are being built now: प्रधान · जिला परिषद wards · पंचायत समिति wards (per PS) · नगर निकाय wards (per ULB) · सरपंच (per PS, SDM) · वार्ड पंच.
3. Which given-number documents exist: state letter for प्रधान SC/ST/OBC; district प्रपत्र-2 for PS SC/ST; OBC Commission table; अधिसूचना 23401 rows for ULBs; ZP sheet header. Ask for each as a file.
4. History registers for offices (सरपंच per GP, प्रधान per PS) since the cycle start (1995): the office's rotation sheet.
5. The switches (see rule 0) — show the Q-list default and let the user pick.

## 2. Ingest → district folder (`scripts/build/SCHEMA.md`; example `example/dausa/`)
- Transcribe each प्रपत्र-ख (ZP, each PS, each ULB) → `wards/*.csv` (two passes, 0 diff). Sum check: ward totals = the sheet's total row.
- `pradhan-units.csv` + `pradhan-history.csv` from the office sheet; `ps-quota.csv` from प्रपत्र-2 + Commission; `ulb-quota.csv` from the notification rows.
- `config.json` from the interview (copy `example/dausa/config.json`, edit every field; `given.*.src` = the document's name).
- Run `python3 scripts/build/build.py <district-dir> --out chakra-<district>.html`.

## 3. Verify before handing over
- `node scripts/build/verify.mjs chakra-<district>.html` — every body: setup → 13 steps → all lotteries recorded → order; 0 page errors; 0 forbidden words (the sweep list is inside verify.mjs — office-vs-engine and internal vocabulary).
- Cross-check the quotas by hand with `scripts/quota.py` for two or three bodies.
- If the office already has sheets: compare (audit-a-hand-sheet method) and write the one-page divergence note — rules quoted in full with the source name.

## 4. Hand over
- `sheets/build-final-sheets.py`, `sheets/build-office-sheets.py`, `sheets/build-summary.py`, then `render-pdf.mjs` for PDFs.
- Give the HTML (open locally or host as a static file), the combined sheets PDF, the summary, the divergence note. Point to § आधार for the sources.
- Record: which documents, which switches, which numbers were derived vs given — in the district's own ledger.

## Where the pieces live
`scripts/build/` — build.py, template.html, tree.json, law-sources.json, verify.mjs, render-pdf.mjs, sheets/, SCHEMA.md, README.md · `example/dausa/` — the worked example (Dausa 2026, 27 bodies) · canonical: `dausa-avsar/chakra/generator/` (SOURCE-VERSION.txt).
