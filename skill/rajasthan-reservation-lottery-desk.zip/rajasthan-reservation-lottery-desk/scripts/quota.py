#!/usr/bin/env python3
"""
quota.py — seat/office QUANTUM calculator for Rajasthan local-body reservation (2026 rules).

Computes, with every step and its clause, for ONE body:
  SC seats, ST seats, OBC seats, the 50% ceiling trim, women's counts (total, per category, general-women).

It does NOT pick WHICH wards (that is the list/lottery stage: r.7(1)-(7), r.7(10)-(13)) — it only gives the numbers.

USAGE
  python3 quota.py --tier ps --seats 15 --sc 10004 --st 29388 --total 56907
  python3 quota.py --tier zp --seats 37 --sc 284214 --st 398172 --total 1305035
  python3 quota.py --tier gp --seats 11 --sc 900 --st 300 --total 4200 --district-scst-pct 52.29
  python3 quota.py --tier ulb --seats 55 --sc-seats 11 --st-seats 6 --obc-seats 9      # ULB: state gives category counts; women = 1/3 nearest per category
  python3 quota.py --tier ps --seats 19 --sc 29677 --st 17311 --total 119185 --obc-seats 2   # OBC given by the Commission (in force)
  python3 quota.py --selftest

OPTIONS
  --tier ps|zp|gp|ulb        PS/ZP/GP member seats (Panchayati Raj Act 1994 s.15) or ULB wards (Municipalities Act 2009 s.6)
  --seats N                  total seats/wards of the body
  --sc / --st / --total      SC population, ST population, TOTAL population of the SAME area (s.15(2): "population of the area")
  --sc-seats / --st-seats    given SC/ST seat counts (state/district letter) — used as-is
  --obc-seats k              given OBC count (OBC Commission / state letter) — used as-is
  --obc-base own|district    base for s.15(3) OBC formula: 'own' = this body's SC+ST% (state practice 2026: Commission tables);
                             'district' = district RURAL SC+ST% (the Act's literal words) — needs --district-scst-pct
  --district-scst-pct x      district rural SC+ST % (Dausa 2026 = 52.29)
  --women-total down|up      odd total: 'down' = state practice (13.08.2026 Pramukh draw 20 of 41; district direction) [default];
                             'up' = s.16 Explanation read literally (half or more → next higher number)
  --no-cap                   do not apply the 50% ceiling (only to SHOW what raw proportion would give)
  --json                     machine-readable output

METHOD (each line prints its clause):
  1. p_SC = SC/total, p_ST = ST/total (integer cross-multiplication precision).
  2. raw SC = round-half-up(N × p_SC); raw ST = round-half-up(N × p_ST)     [s.15(2) + s.16 Explanation]
  3. OBC: if base% < 50 → p = min(21, 50 − base%), OBC = round-half-up(N × p/100); if base% ≥ 50 → 0;
     proviso: if base% ≤ 70 → at least 1.                                  [s.15(3) + proviso]
  4. Ceiling: SC+ST+OBC ≤ floor(N/2)                                       [K. Krishna Murthy (2010) 7 SCC 202 para 48(iv); Gawali (2021)]
     if breached and SC/ST are NOT given: R = cap − OBC, split R between SC and ST in the ratio p_SC : p_ST
     (whole numbers first, leftover seat to the larger remainder; tie → larger population). This is the state's/district's
     observed method (reproduces Dausa ZP 7/10 and 13 of 14 PS sheets; the text is SILENT on the split → declare it, D-node).
     if breached and SC/ST ARE given: numbers are printed with a BREACH flag — refer to the department, do not conduct.
  5. Women: total W = N ÷ 2 (down = floor; up = round-half-up)              [r.6(2), r.7(9); s.15(6) "not less than one-half"; s.16 Expl.]
     category women = floor(cat ÷ 2) each                                    [r.7(8)(a); state practice 13.08.2026: 4 of 8, 3 of 7, 2 of 5]
     one-each rule: SC=ST=OBC=1 → one of the three by lot carries the women's tag [r.7(8)(b)]
     general-women = W − Σ category-women, capped at the unreserved pool     [r.7(9)]
  ULB: category counts come from the state (अधिसूचना); women per category = round-nearest(count ÷ 3) [DLB 2026 tables; Municipalities Act s.6 as applied since Manak Chand 2010].
"""
import argparse, json, math, sys

def rhu(x):            # round half up
    return math.floor(x + 0.5)

def nearest(x):        # round to nearest, .5 up
    return math.floor(x + 0.5)

def hamilton_split(R, wa, wb, pop_a, pop_b):
    """split R whole seats between a and b in ratio wa:wb; leftover to larger remainder; tie → larger population."""
    if R <= 0: return 0, 0, "R ≤ 0"
    if wa + wb == 0: return 0, 0, "no population"
    xa = R * wa / (wa + wb); xb = R * wb / (wa + wb)
    a, b = math.floor(xa), math.floor(xb)
    left = R - a - b
    note = f"{R} × {wa:.4g}/({wa:.4g}+{wb:.4g}) = {xa:.2f} → {a}; {R} × {wb:.4g}/({wa:.4g}+{wb:.4g}) = {xb:.2f} → {b}"
    if left > 0:
        ra, rb = xa - a, xb - b
        if ra > rb or (ra == rb and pop_a >= pop_b):
            a += left; note += f"; leftover {left} → SC (remainder {ra:.2f} > {rb:.2f})"
        else:
            b += left; note += f"; leftover {left} → ST (remainder {rb:.2f} > {ra:.2f})"
    return a, b, note

def compute(tier, N, sc=None, st=None, total=None, sc_seats=None, st_seats=None, obc_seats=None,
            obc_base="own", district_scst_pct=None, women_total="down", cap_on=True):
    steps = []
    out = {"tier": tier, "seats": N}
    def step(k, v, how, clause):
        steps.append({"item": k, "value": v, "how": how, "clause": clause}); out[k] = v

    if tier == "ulb":
        # state gives category counts; women 1/3 nearest per category (as applied by DLB 2026)
        if None in (sc_seats, st_seats, obc_seats):
            raise SystemExit("ULB: give --sc-seats --st-seats --obc-seats (from the अधिसूचना); population inputs are not used")
        gen = N - sc_seats - st_seats - obc_seats
        step("SC", sc_seats, "given (अधिसूचना)", "Municipalities Act 2009 s.6(1); DLB letter")
        step("ST", st_seats, "given (अधिसूचना)", "s.6(1)")
        step("OBC", obc_seats, "given (अधिसूचना)", "s.6(1)(a)(ii) as amended 2010; OBC Commission")
        step("GEN", gen, f"{N} − {sc_seats} − {st_seats} − {obc_seats}", "remainder")
        tot_res = sc_seats + st_seats + obc_seats
        step("reserved_share_pct", round(tot_res / N * 100, 1), f"{tot_res}/{N}", "K. Krishna Murthy (2010) 7 SCC 202 — vertical total ≤ 50%")
        if tot_res > N // 2: out["BREACH_50"] = True
        for k, n in (("SC", sc_seats), ("ST", st_seats), ("OBC", obc_seats), ("GEN", gen)):
            w = nearest(n / 3)
            step(f"W_{k}", w, f"{n} ÷ 3 = {n/3:.2f} → nearest {w}", "one-third per category, nearest (DLB 2026 tables; s.6(6)-(7) as applied post Manak Chand 2010)")
        step("W_total", out["W_SC"] + out["W_ST"] + out["W_OBC"] + out["W_GEN"], "sum of category women (no separate total computation in the DLB tables)", "—")
        out["summary"] = f"{N} wards → SC {sc_seats} (महिला {out['W_SC']}), ST {st_seats} (महिला {out['W_ST']}), OBC {obc_seats} (महिला {out['W_OBC']}), GEN {gen} (महिला {out['W_GEN']}); women total {out['W_total']}"
        return out, steps

    # ---- PRI member seats (PS/ZP/GP) ----
    if sc_seats is None or st_seats is None:
        if None in (sc, st, total) or total <= 0:
            raise SystemExit("PRI: give --sc --st --total (populations of the SAME area) or --sc-seats/--st-seats")
    p_sc = (sc / total) if total else 0.0
    p_st = (st / total) if total else 0.0
    if total:
        step("SC_pct", round(p_sc * 100, 2), f"{sc}/{total}", "s.15(2): population of such Castes ÷ total population of the area")
        step("ST_pct", round(p_st * 100, 2), f"{st}/{total}", "s.15(2)")
    given_scst = sc_seats is not None and st_seats is not None
    if given_scst:
        raw_sc, raw_st = sc_seats, st_seats
        step("SC_raw", raw_sc, "given (state/district letter) — in force", "s.15(2); Circular 62 ¶2")
        step("ST_raw", raw_st, "given (state/district letter) — in force", "s.15(2); Circular 62 ¶2")
    else:
        raw_sc = rhu(N * p_sc); raw_st = rhu(N * p_st)
        step("SC_raw", raw_sc, f"round-half-up({N} × {p_sc*100:.2f}%) = round-half-up({N*p_sc:.2f})", "s.15(2) + s.16 Explanation (half or more → next higher)")
        step("ST_raw", raw_st, f"round-half-up({N} × {p_st*100:.2f}%) = round-half-up({N*p_st:.2f})", "s.15(2) + s.16 Explanation")

    # OBC
    if obc_seats is not None:
        obc = obc_seats
        step("OBC", obc, "given (OBC Commission / letter) — in force", "s.15(3); Circular 62 ¶2")
        base_pct = None
    else:
        if obc_base == "district":
            if district_scst_pct is None: raise SystemExit("--obc-base district needs --district-scst-pct")
            base_pct = district_scst_pct; base_lbl = "district rural SC+ST%"
        else:
            base_pct = (p_sc + p_st) * 100; base_lbl = "this body's own SC+ST% (state practice 2026 — Commission tables; the Act's words say district rural: Q-11)"
        if base_pct < 50:
            p = min(21.0, 50.0 - base_pct); f = rhu(N * p / 100)
            how = f"base {base_pct:.2f}% < 50 → p = min(21, 50 − {base_pct:.2f}) = {p:.2f}% → round-half-up({N} × {p:.2f}%) = {f}"
        else:
            f = 0; how = f"base {base_pct:.2f}% ≥ 50 → formula 0"
        floor1 = 1 if base_pct <= 70 else 0
        obc = max(f, floor1)
        how += f"; proviso: base ≤ 70% → at least 1 ({floor1})" if base_pct <= 70 else "; proviso off (base > 70%)"
        step("OBC", obc, how + f" [base = {base_lbl}]", "s.15(3) + proviso")

    cap = N // 2
    step("cap_50", cap, f"floor({N}/2)", "K. Krishna Murthy v UOI (2010) 7 SCC 202 para 48(iv); Vikas Gawali (2021) 6 SCC 73 para 67 — SC+ST+OBC vertical total ≤ 50%")
    sc_n, st_n = raw_sc, raw_st
    total_res = sc_n + st_n + obc
    out["BREACH_50"] = False
    if cap_on and total_res > cap:
        if given_scst:
            out["BREACH_50"] = True
            step("BREACH", f"{sc_n}+{st_n}+{obc} = {total_res} > {cap}", "given numbers exceed the ceiling — do NOT conduct; refer to the department in writing (Circular 62 ¶6 route) with this sum",
                 "Krishna Murthy 2010; Gawali 2021 para 28 (excess quashed, filled as open)")
        else:
            R = cap - obc
            a, b, note = hamilton_split(R, p_sc, p_st, sc or 0, st or 0)
            step("SC", a, f"ceiling trim: R = {cap} − {obc} = {R}; {note}", "state/district method 2026 (reproduces Dausa ZP 7/10, 13/14 PS); text silent on the split → declare in proceedings")
            step("ST", b, "as above", "as above")
            sc_n, st_n = a, b
    else:
        step("SC", sc_n, "raw count stands (within ceiling)" if cap_on else "raw (ceiling not applied)", "s.15(2)")
        step("ST", st_n, "raw count stands (within ceiling)" if cap_on else "raw (ceiling not applied)", "s.15(2)")
    gen = N - sc_n - st_n - obc
    step("GEN", gen, f"{N} − {sc_n} − {st_n} − {obc}", "unreserved remainder")
    step("reserved_share_pct", round((sc_n + st_n + obc) / N * 100, 1), f"({sc_n}+{st_n}+{obc})/{N}", "≤ 50% check")

    # women
    if women_total == "up":
        W = rhu(N / 2); howW = f"round-half-up({N}/2) — s.16 Explanation read literally"
    else:
        W = N // 2; howW = f"floor({N}/2) — state practice (13.08.2026 Pramukh: 20 of 41) / department direction; s.16 Explanation would give {rhu(N/2)}"
    step("W_total", W, howW, "r.6(2) 'one half … of the total number of seats'; r.7(9) 'dividing the total number of seats by two'; s.15(6) 'not less than one-half'")
    w_sc, w_st, w_obc = sc_n // 2, st_n // 2, obc // 2
    one_each = (sc_n == 1 and st_n == 1 and obc == 1)
    if one_each:
        step("W_SC/ST/OBC", "1 of the three by lot", "one seat each reserved for SC, ST, OBC → one of the three, by draw of lots, is the women's seat (keeps its category)", "r.7(8)(b)")
        cat_w = 1
    else:
        step("W_SC", w_sc, f"floor({sc_n}/2)", "r.7(8)(a) 'dividing … by two'; floor per category = department method (13.08.2026: 4 of 8, 3 of 7, 2 of 5); Q-4 open")
        step("W_ST", w_st, f"floor({st_n}/2)", "r.7(8)(a)")
        step("W_OBC", w_obc, f"floor({obc}/2)", "r.7(8)(a) (r.7(7)'s 'one third' for BC-women is unamended 1994 residue; Circular 62 ¶4(v): 50% in every category)")
        cat_w = w_sc + w_st + w_obc
    gw = W - cat_w
    note = f"{W} − {cat_w}"
    if gw > gen:
        note += f" = {gw} > unreserved pool {gen} → capped at {gen}, shortfall {gw-gen} recorded (refer if material)"; gw = gen
    if gw < 0: gw = 0
    step("W_GEN", gw, note, "r.7(9) 'remaining number of seats reserved for women … reduced by the aggregate … under sub-rule (8)'")
    out["summary"] = f"{N} seats → SC {sc_n} (महिला {w_sc if not one_each else '?'}), ST {st_n} (महिला {w_st if not one_each else '?'}), OBC {obc} (महिला {w_obc if not one_each else '?'}), GEN {gen} (महिला {gw}); women total {W}"
    return out, steps

def selftest():
    cases = [
        # (label, kwargs, expected SC, ST, OBC, W_total, W_GEN)
        ("Dausa ZP 37",        dict(tier="zp", N=37, sc=284214, st=398172, total=1305035), 7, 10, 1, 18, 10),
        ("PS बैजूपाड़ा 15",     dict(tier="ps", N=15, sc=10004, st=29388, total=56907), 2, 4, 1, 7, 4),
        ("PS नांगल राजावतान 17", dict(tier="ps", N=17, sc=21147, st=57053, total=104983), 2, 6, 0, 8, 4),
        ("PS शिवसिंहपुरा 15",   dict(tier="ps", N=15, sc=12568, st=34558, total=62289), 2, 5, 0, 7, 4),
        ("PS बांदीकुई 23",      dict(tier="ps", N=23, sc=27142, st=18665, total=147970), 4, 3, 4, 11, 6),
        ("PS दौसा 21",         dict(tier="ps", N=21, sc=30548, st=31674, total=135610), 4, 5, 1, 10, 6),
        ("PS महवा 15",         dict(tier="ps", N=15, sc=19978, st=19513, total=78642), 3, 3, 1, 7, 5),
        ("PS सिकराय 19",       dict(tier="ps", N=19, sc=24760, st=41949, total=125361), 3, 5, 1, 9, 6),
        ("PS लालसोट 19",       dict(tier="ps", N=19, sc=31261, st=34931, total=127342), 4, 4, 1, 9, 5),
        ("PS लवाण 15",         dict(tier="ps", N=15, sc=14453, st=11540, total=48697), 3, 3, 1, 7, 5),
        ("PS बसवा 15",         dict(tier="ps", N=15, sc=11736, st=19087, total=66220), 2, 4, 1, 7, 4),
        ("PS रामगढ़ पचवारा 17", dict(tier="ps", N=17, sc=20495, st=53290, total=106707), 2, 5, 1, 8, 5),
        ("PS मनोहरपुर खेडला 15", dict(tier="ps", N=15, sc=19633, st=11911, total=74233), 4, 2, 1, 7, 4),
        ("Q example 15 seats SC20/ST48%", dict(tier="ps", N=15, sc=200, st=480, total=1000), 2, 4, 1, 7, 4),
    ]
    bad = 0
    for label, kw, esc, est, eobc, ew, egw in cases:
        o, _ = compute(**kw)
        ok = (o["SC"], o["ST"], o["OBC"], o["W_total"], o["W_GEN"]) == (esc, est, eobc, ew, egw)
        print(("PASS " if ok else "FAIL ") + label, "→", o["summary"])
        if not ok:
            bad += 1; print("   expected", esc, est, eobc, "women", ew, "gen-w", egw)
    # known deviation: सिकन्दरा — district sheet 5/2/2 keeps SC raw and cuts ST; Hamilton gives 4/3/2. Print, don't assert.
    o, _ = compute(tier="ps", N=19, sc=29677, st=17311, total=119185)
    print("NOTE सिकन्दरा 19: engine", o["SC"], o["ST"], o["OBC"], "| district sheet 5/2/2 (kept SC at raw 5, cut ST) — text silent on the split; given numbers are in force")
    # ULB
    o, _ = compute(tier="ulb", N=55, sc_seats=11, st_seats=6, obc_seats=9)
    print(("PASS " if (o["W_SC"], o["W_ST"], o["W_OBC"], o["W_GEN"]) == (4, 2, 3, 10) else "FAIL ") + "ULB दौसा 55 (DLB 4/2/3/10) →", o["W_SC"], o["W_ST"], o["W_OBC"], o["W_GEN"])
    print("selftest:", "ALL PASS" if bad == 0 else f"{bad} FAIL")
    return bad

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--tier", choices=["ps", "zp", "gp", "ulb"])
    ap.add_argument("--seats", type=int)
    ap.add_argument("--sc", type=int); ap.add_argument("--st", type=int); ap.add_argument("--total", type=int)
    ap.add_argument("--sc-seats", type=int); ap.add_argument("--st-seats", type=int); ap.add_argument("--obc-seats", type=int)
    ap.add_argument("--obc-base", choices=["own", "district"], default="own")
    ap.add_argument("--district-scst-pct", type=float)
    ap.add_argument("--women-total", choices=["down", "up"], default="down")
    ap.add_argument("--no-cap", action="store_true")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--selftest", action="store_true")
    a = ap.parse_args()
    if a.selftest:
        sys.exit(1 if selftest() else 0)
    if not a.tier or not a.seats:
        ap.print_help(); sys.exit(2)
    out, steps = compute(a.tier, a.seats, a.sc, a.st, a.total, a.sc_seats, a.st_seats, a.obc_seats,
                         a.obc_base, a.district_scst_pct, a.women_total, not a.no_cap)
    if a.json:
        print(json.dumps({"result": out, "steps": steps}, ensure_ascii=False, indent=1)); return
    print(f"\n{a.tier.upper()} · {a.seats} seats\n" + "-" * 72)
    for s in steps:
        print(f"{s['item']:<20} {str(s['value']):<12} {s['how']}\n{'':<20} {'':<12} [{s['clause']}]")
    print("-" * 72 + "\n" + out["summary"])
    if out.get("BREACH_50"): print("\n!! 50% CEILING BREACHED BY GIVEN NUMBERS — refer to the department before the draw.")

if __name__ == "__main__":
    main()
